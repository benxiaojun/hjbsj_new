var zhushu = new Array();
var hunyan = new Array();
var hunyan_price = new Array();
var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
angular.module('starter.controllers', [])

    .controller('LoginCtrl', function($scope, LoginService, $ionicPopup, $state,$http,$ionicHistory,$cordovaToast,$ionicLoading) {
        $ionicHistory.clearCache();
        $scope.data = {};
        if (typeof($scope.data.username) == "undefined" || $scope.data.username == "") {
            $scope.data.username = window.localStorage['userName'];
        }
        if(typeof($scope.data.password) == "undefined" || $scope.data.password == ""){
            $scope.data.password = window.localStorage['userPassword'];
        }
        //window.addEventListener('native.showkeyboard', function(){
        //  $(".div-bottom-ud").css({position:'relative'});
        //});
        //window.addEventListener('native.hidekeyboard', function(){
        //  $(".div-bottom-ud").css({position:'fixed'});
        //});

          $scope.login = function() {
              //$http({
              //    method: 'POST',
              //    url: 'http://jddq.honghuowang.com/wap/index.php?ctl=biz_login&post_type=json',
              //    headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
              //    data:{
              //        biz_account:$scope.data.username,biz_pwd:$scope.data.password
              //    }
              //}).success(function(data,status,headers,config){
              //    if(data.biz_login_status === 1){
              //        $state.go("accountCenter");
              //    }else{
              //        $ionicPopup.alert({
              //          title:'登录失败',
              //          template:data.info
              //        })
              //    }
              //}).error(function(data,status,headers,config){
              //    $ionicPopup.alert({
              //        title:'登录失败',
              //        template:data.info
              //    })
              //});
              if(window.Connection) {
                  if(navigator.connection.type == Connection.NONE) {
                      $cordovaToast.showShortCenter("网络不给力，请网络良好时再试");
                      return;
                  }
              }
              $ionicLoading.show({
                  template: '<span style="font-family: 黑体">正在登录中，请稍后...</span>',
                  hideOnStateChange:true,
                  duration:5000
              });
              //登录
              LoginService.loginUser($scope.data.username, $scope.data.password);

          };
            $scope.forgetPwd = function(){
                $ionicPopup.alert({
                    title:"忘记密码",
                    template:"<div align='center'>为保证商户账户安全</br>请致电客服电话400-838-5018</br>进行申请密码重置服务</div>",
                    okText: '确定',
                    okType: "button-royal"
                })
            };
    })
    .controller('settingCtrl', function($scope, $state,LoginService,$ionicHistory) {
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.logout = function(){
            LoginService.logout();
        }
    })
    .controller('allAppointmentCtrl',function($scope, $state,$stateParams,$ionicPopover,OrderService,UserService,$timeout,$ionicHistory,$rootScope){
        $ionicHistory.clearCache();
        $scope.yanghuiting_count = $stateParams.yanghuiting_count;
        $scope.yanghuiting_list = $stateParams.yanghuiting_list;

        //下拉刷新
        $scope.doRefresh_allAppointment = function() {
            $timeout( function() {
                OrderService.query_allAppointment().then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                    $scope.yanghuiting_count = results.yanghuiting_count;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };
        $scope.doRefresh_allAppointment();

        $scope.slide_allAppointment = function(index){
            $("#detail_yyzb"+index).slideToggle();
            var up_arroe_state =$("#up_arrow_yyzb"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow_yyzb"+index).css('display','block');
                $("#down_arrow_yyzb"+index).css('display','none');
            }else{
                $("#up_arrow_yyzb"+index).css('display','none');
                $("#down_arrow_yyzb"+index).css('display','block');
            }
        };
        //$scope.expand_yyzb = function(index){
        //    $("#detail_yyzb"+index).slideToggle();
        //    //document.getElementById("detail_yyzb"+index).style.display="block";
        //    document.getElementById("up_arrow_yyzb"+index).style.display = "none";
        //    document.getElementById("down_arrow_yyzb"+index).style.display = "block";
        //}
        //$scope.collapse_yyzb = function(index){
        //    $("#detail_yyzb"+index).slideToggle();
        //    //document.getElementById("detail_yyzb"+index).style.display="none";
        //    document.getElementById("up_arrow_yyzb"+index).style.display = "block";
        //    document.getElementById("down_arrow_yyzb"+index).style.display = "none";
        //}

        $scope.goto_accountCenter = function(){
            UserService.get_sj_info();
        };

        $ionicPopover.fromTemplateUrl("popover.html", {
            scope: $scope
        }).then(function(popover){
                $scope.popover = popover;
            })
        $scope.openPopover = function($event) {
            $scope.popover.show($event);
        };
        $scope.closePopover = function() {
            $scope.popover.hide();
        };
        //销毁事件回调处理：清理popover对象
        $scope.$on("$destroy", function() {
            $scope.popover.remove();
        });
        $scope.goto_schedule_calendar = function(){
            OrderService.get_schedule_info();
        };
        $scope.jump_to_yuyue_tab = function(dangqi){
            OrderService.get_yuyue_info(dangqi);
        };
        $scope.jump_to_kanchang_tab = function(){
            var date = new Date();
            var month = date.getMonth()+1;
            var dangqi = date.getFullYear()+"."+month+"."+date.getDate();
            OrderService.get_kanchang_info(dangqi);
            $scope.popover.hide();
        };
        $scope.jump_to_yuding_tab = function(){
            var date = new Date();
            var month = date.getMonth()+1;
            var dangqi = date.getFullYear()+"."+month+"."+date.getDate();
            OrderService.get_yuding_info(dangqi);
            $scope.popover.hide();
        };
    })
    //.controller('yuyue_zongbiao_ctrl',function($scope, $state,$stateParams,$ionicPopover,OrderService,UserService,$timeout,$ionicHistory){
    //
    //})
    .controller('scheduleShowCtrl',function($scope,$stateParams,UserService,OrderService,$rootScope,$ionicHistory,$cordovaToast,$state,$timeout){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.yuyueAdd = function(date){
            OrderService.get_yuyue_add_info(date).then(function(results) {
                if(results.yanghuiting_list == null){
                    $cordovaToast.showShortTop("该档期下无可预约宴会厅！");
                    return;
                }else{
                    $state.go("yuyueAdd",{dangqi:date});
                }
            });
        };
        $scope.sj_name = $stateParams.sj_name;
        $scope.items = $stateParams.items;
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        UserService.query_schedule_info(year,month,day).then(function(results){
            $scope.zhuting_status_format = results.item.zhuting_status_format;
            $scope.futing_status_format = results.item.futing_status_format;
        });
        $("#selected_date").html(year+"."+month+"."+day);
        $timeout(function(){
            $("#lunar_date").html($("#ly"+day).text()+"<br>"+$("#lmd"+day).text());
        },500);
        $scope.dangqi = year+"."+month+"."+day;
        var selected_date_array = new Array();
        $(function() {
            $(document).on('shown.calendar.calendario', function(e, instance){
                selected_date_array = new Array();
                if(!instance) instance = cal;
                var $cell = instance.getCell(new Date().getDate());
                //if($cell.hasClass('fc-today')) $cell.trigger('click.calendario');
                $scope.instance = instance;
                UserService.query_schedule_info(instance.getYear(),instance.getMonth(),null).then(function(results){
                    var items = results.item;
                    for(var key in items){
                        //$scope.instance.getCell(parseInt(key)).removeClass("fc-close");
                        if(items[key].dangqi_status == 1){
                            $scope.instance.getCell(parseInt(key)).addClass("fc-dangqi-jinzhang");
                        }else if(items[key].dangqi_status == 2){
                            $scope.instance.getCell(parseInt(key)).addClass("fc-dangqi-full");
                        }
                    }
                });
            });

            var transEndEventNames = {
                    'WebkitTransition' : 'webkitTransitionEnd',
                    'MozTransition' : 'transitionend',
                    'OTransition' : 'oTransitionEnd',
                    'msTransition' : 'MSTransitionEnd',
                    'transition' : 'transitionend'
                },
                transEndEventName = transEndEventNames[ Modernizr.prefixed( 'transition' ) ],
                $wrapper = $( '#custom-inner' ),
                $calendar = $( '#calendar' ),
                cal = $calendar.calendario({
                    onDayClick : function( $el, data, dateProperties ) {
                        $scope.dangqi = dateProperties.year+"."+dateProperties.month+"."+dateProperties.day;
                        $scope.pdate = parseInt(dateProperties.year + parse_date(dateProperties.month) + parse_date(dateProperties.day));
                        if($el[0].firstChild.className !="fc-date fc-emptydate"){
                            $("#selected_date").html(dateProperties.year+"."+dateProperties.month+"."+dateProperties.day);
                            $("#lunar_date").html($("#ly"+dateProperties.day).text()+"<br>"+$("#lmd"+dateProperties.day).text());
                            UserService.query_schedule_info(dateProperties.year,dateProperties.month,dateProperties.day).then(function(results){
                                $scope.zhuting_status_format = results.item.zhuting_status_format;
                                $scope.futing_status_format = results.item.futing_status_format;
                                $scope.zhuting_status = results.item.zhuting_status;
                                $scope.futing_status = results.item.futing_status;
                            });
                            for(var i = 1;i<=31;i++){
                                if(i == parseInt(dateProperties.day)){
                                    $el[0].classList.add("fc-selected");
                                }else if($scope.instance != undefined){
                                    $scope.instance.getCell(parseInt(i)).removeClass("fc-selected");
                                }
                            }
                            //var has_in = false;
                            //for (var key in selected_date_array) {
                            //    if (selected_date_array[key] === $scope.pdate) {
                            //        selected_date_array.splice(key,1);
                            //        $el[0].classList.remove("fc-selected");
                            //        has_in = true;
                            //        break;
                            //    }
                            //}
                            //if(!has_in){
                            //    selected_date_array.push($scope.pdate);
                            //    $el[0].classList.add("fc-selected");
                            //}
                        }
                    },
                    //caldata : codropsEvents,
                    weekabbrs  : [ '日', '一', '二', '三', '四', '五', '六' ],
                    //monthabbrs : [ '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月' ],
                    months  : [ '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月' ],
                    displayWeekAbbr : true,
                    // left-most day in the calendar  0- Sunday, 1 - Monday, ... , 6 - Saturday
                    startIn : 0,
                    events: 'click'
                } ),
                $month = $( '#custom-month' ).html( cal.getMonthName() ),
                $year = $( '#custom-year' ).html( cal.getYear() );

            //cal.setData(codropsEvents);

            $( '#custom-next' ).on( 'click', function() {
                cal.gotoNextMonth( updateMonthYear );
            } );
            $( '#custom-prev' ).on( 'click', function() {
                cal.gotoPreviousMonth( updateMonthYear );
            } );
            function updateMonthYear() {
                $month.html( cal.getMonthName() );
                $year.html( cal.getYear() );
                selected_date_array = new Array();
            }
            // just an example..
            function showEvents( contentEl, dateProperties ) {
                hideEvents();
                var $events = $( '<div id="custom-content-reveal" class="custom-content-reveal"><h4>Events for ' + dateProperties.monthname + ' ' + dateProperties.day + ', ' + dateProperties.year + '</h4></div>' ),
                    $close = $( '<span class="custom-content-close"></span>' ).on( 'click', hideEvents );
                $events.append( contentEl.join('') , $close ).insertAfter( $wrapper );
                setTimeout( function() {
                    $events.css( 'top', '0%' );
                }, 25 );
            }
            function hideEvents() {
                var $events = $( '#custom-content-reveal' );
                if( $events.length > 0 ) {
                    $events.css( 'top', '100%' );
                    Modernizr.csstransitions ? $events.on( transEndEventName, function() { $( this ).remove(); } ) : $events.remove();
                }
            }
        });

        $scope.jump_to_yuyue_tab = function(){
            OrderService.get_yuyue_info($scope.dangqi);
        };
        $scope.jump_to_tab = function(flag){
            if(flag ==1){
                if($scope.zhuting_status == 2){
                    OrderService.get_yuding_info($scope.dangqi);
                }else{
                    OrderService.get_yuyue_info($scope.dangqi);
                }
            }else{
                if($scope.futing_status == 2){
                    OrderService.get_yuding_info($scope.dangqi);
                }else{
                    OrderService.get_yuyue_info($scope.dangqi);
                }
            }
        }
    })
    .controller('tabsCtrl',function($scope,$stateParams,OrderService,$timeout,$ionicHistory,$ionicModal,$rootScope,$cordovaToast,$state){
        //OrderService.get_yuyue_info();
        $ionicHistory.clearCache();
        $scope.backGo = function(){
            if($ionicHistory.backView().stateName == "yuyueAdd"){
                $ionicHistory.goBack(-2);
            }else{
                $ionicHistory.goBack();
            }
        };
        $scope.yuyueAdd = function(dangqi){
            OrderService.get_yuyue_add_info(dangqi).then(function(results) {
                if(results.yanghuiting_list == null){
                    $cordovaToast.showShortTop("该档期下无可预约宴会厅！");
                    return;
                }else{
                    $state.go("yuyueAdd",{dangqi:dangqi});
                }
            });
        };
        $scope.dangqi = $stateParams.dangqi;
        $scope.yanghuiting_count = $stateParams.yanghuiting_count;
        $scope.yanghuiting_list = $stateParams.yanghuiting_list;
        //$scope.goto_schedule = function(dangqi){
        //    $state.go("scheduleShowPage");
        //};
        $scope.goto_schedule_calendar = function(){
            OrderService.get_schedule_info();
        };
        //选中tab事件
        //选中全部tab
        $scope.on_select_all = function(dangqi){
            OrderService.query_all(dangqi).then(function(results){
                $scope.yanghuiting_list = results.yanghuiting_list;
            });
        };
        //选中预约tab
        $scope.on_select_yuyue = function(dangqi){
            //OrderService.query_yuyue(dangqi).then(function (results) {
            //    $scope.yanghuiting_list = results.yanghuiting_list;
            //});
            $timeout( function() {
                $rootScope.doRefresh_yuyue(dangqi);
            }, 1000);
            //预约处理模态框
            $ionicModal.fromTemplateUrl("yuyue_modal.html", {
                scope: $scope,
                animation: "slide-in-up"
            }).then(function(modal) {
                $scope.yuyue_modal = modal;
            });
            $scope.open_yuyue_modal = function(yyid,roomid) {
                OrderService.get_yuyue_detail(yyid).then(function(results){
                    $rootScope.yanghuiting_list_yuyue_modal = results.yanghuiting_list;
                    $scope.yanghuiting_list1 = results.yanghuiting_list;
                    $scope.room_one = results.yanghuiting_list[roomid];
                    $scope.yanghuiting_count1 = results.yanghuiting_count;
                    $scope.item = results.item;
                    if(results.yanghuiting_count > 1) {
                        $scope.is_show_yuyue = true;
                    }else{
                        $scope.is_show_yuyue = false;
                    }
                    $scope.total_price = $scope.item.total_price;
                });
                $scope.yuyue_modal.show();
                $('#yuyue_dangqi').focus(function() {
                    this.blur();
                });
                $('#kc_date').focus(function() {
                    this.blur();
                });
                $('#kc_time').focus(function() {
                    this.blur();
                });
                $("#yuyue_kc_dec").attr('disabled',true);
            };
            $scope.closeModal = function() {
                $scope.yuyue_modal.remove();
                $scope.on_select_yuyue($scope.dangqi);
            };
        };
        //选中看场tab
        $scope.on_select_kanchang = function(dangqi){
            OrderService.query_kanchang(dangqi).then(function(results){
                $scope.yanghuiting_list = results.yanghuiting_list;
            });
            //看场处理模态框
            $ionicModal.fromTemplateUrl("kanchang_modal.html", {
                scope: $scope,
                animation: "slide-in-up"
            }).then(function(modal) {
                $scope.kanchang_modal = modal;
            });
            $scope.open_kanchang_modal = function(id,roomid) {
                OrderService.get_kanchang_detail(id).then(function(results){
                    $scope.yanghuiting_list1 = results.yanghuiting_list;
                    $scope.room_one = results.yanghuiting_list[roomid];
                    $scope.yanghuiting_count1 = results.yanghuiting_count;
                    $scope.item = results.item;
                    if(results.yanghuiting_count > 1) {
                        $scope.is_show_kanchang = true;
                    }else{
                        $scope.is_show_kanchang = false;
                    }
                    $scope.total_price = $scope.item.total_price;
                })
                $scope.kanchang_modal.show();
                $('#kc_dangqi').focus(function() {
                    this.blur();
                });
            };
            $scope.closeModal = function() {
                $scope.kanchang_modal.remove();
                $scope.on_select_kanchang($scope.dangqi);
            };
        };
        //选中预定tab
        $scope.on_select_yuding = function(dangqi){
            OrderService.query_yuding(dangqi).then(function(results){
                $scope.yanghuiting_list = results.yanghuiting_list;
            });
        };
    })

    .controller('ctr',function($scope,$ionicTabsDelegate,$stateParams){
        $ionicTabsDelegate.select($stateParams.index);
    })

    .controller('tab_yuyue_ctrl',function($scope,$rootScope,$timeout,OrderService,$ionicModal,$ionicHistory,$state){
        //$ionicHistory.clearCache();
        OrderService.query_yuyue($scope.dangqi).then(function(results){
            $scope.yanghuiting_list = results.yanghuiting_list;
        });

        $rootScope.doRefresh_yuyue = function(date) {
            var dangqi = date == undefined ? $scope.dangqi:date;
            $timeout( function() {
                OrderService.query_yuyue(dangqi).then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

        $scope.slide_yuyue = function(index){
            $("#detail_yy"+index).slideToggle();
            var up_arroe_state =$("#up_arrow_yy"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow_yy"+index).css('display','block');
                $("#down_arrow_yy"+index).css('display','none');
            }else{
                $("#up_arrow_yy"+index).css('display','none');
                $("#down_arrow_yy"+index).css('display','block');
            }
        };
        //$scope.expand_yy = function(index){
        //    $("#detail_yy"+index).slideToggle();
        //    //document.getElementById("detail_yy"+index).style.display="block";
        //    document.getElementById("up_arrow_yy"+index).style.display = "none";
        //    document.getElementById("down_arrow_yy"+index).style.display = "block";
        //}
        //$scope.collapse_yy = function(index){
        //    $("#detail_yy"+index).slideToggle();
        //    //document.getElementById("detail_yy"+index).style.display="none";
        //    document.getElementById("up_arrow_yy"+index).style.display = "block";
        //    document.getElementById("down_arrow_yy"+index).style.display = "none";
        //}

    })
    .controller('tab_all_ctrl',function($scope,$timeout,$rootScope,OrderService){
        //下拉刷新
        $scope.doRefresh_all = function() {
            $timeout( function() {
                OrderService.query_all($scope.dangqi).then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

        $scope.slide_all = function(index){
            $("#detail_all"+index).slideToggle();
            var up_arroe_state =$("#up_arrow_all"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow_all"+index).css('display','block');
                $("#down_arrow_all"+index).css('display','none');
            }else{
                $("#up_arrow_all"+index).css('display','none');
                $("#down_arrow_all"+index).css('display','block');
            }
        };
        //$scope.expand_all = function(index){
        //    $("#detail_all"+index).slideToggle();
        //    //document.getElementById("detail_all"+index).style.display="block";
        //    document.getElementById("up_arrow_all"+index).style.display = "none";
        //    document.getElementById("down_arrow_all"+index).style.display = "block";
        //};
        //$scope.collapse_all = function(index){
        //    $("#detail_all"+index).slideToggle();
        //    //document.getElementById("detail_all"+index).style.display="none";
        //    document.getElementById("up_arrow_all"+index).style.display = "block";
        //    document.getElementById("down_arrow_all"+index).style.display = "none";
        //}
    })

    .controller('tab_kanchang_ctrl',function($scope,$timeout,$ionicModal,OrderService,$state,$rootScope){
        $rootScope.doRefresh_kanchang = function(date) {
            var dangqi = date == undefined ? $scope.dangqi:date;
            $timeout( function() {
                OrderService.query_kanchang(dangqi).then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

        $scope.slide_kanchang = function(index){
            $("#detail_kanchang"+index).slideToggle();
            var up_arroe_state =$("#up_arrow_kanchang"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow_kanchang"+index).css('display','block');
                $("#down_arrow_kanchang"+index).css('display','none');
            }else{
                $("#up_arrow_kanchang"+index).css('display','none');
                $("#down_arrow_kanchang"+index).css('display','block');
            }
        };
        //$scope.expand_kanchang = function(index){
        //    $("#detail_kanchang"+index).slideToggle();
        //    //document.getElementById("detail_kanchang"+index).style.display="block";
        //    document.getElementById("up_arrow_kanchang"+index).style.display = "none";
        //    document.getElementById("down_arrow_kanchang"+index).style.display = "block";
        //};
        //$scope.collapse_kanchang = function(index){
        //    $("#detail_kanchang"+index).slideToggle();
        //    //document.getElementById("detail_kanchang"+index).style.display="none";
        //    document.getElementById("up_arrow_kanchang"+index).style.display = "block";
        //    document.getElementById("down_arrow_kanchang"+index).style.display = "none";
        //};
    })

    .controller('tab_yuding_ctrl',function($scope,$timeout,OrderService,$rootScope){
        $rootScope.doRefresh_yuding = function(date) {
            var dangqi = date == undefined ? $scope.dangqi:date;
            $timeout( function() {
                OrderService.query_yuding(dangqi).then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

        $scope.slide_yuding = function(index){
            $("#detail_yuding"+index).slideToggle();
            var up_arroe_state =$("#up_arrow_yuding"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow_yuding"+index).css('display','block');
                $("#down_arrow_yuding"+index).css('display','none');
            }else{
                $("#up_arrow_yuding"+index).css('display','none');
                $("#down_arrow_yuding"+index).css('display','block');
            }
        };
        //$scope.expand_yuding = function(index){
        //    $("#detail_yuding"+index).slideToggle();
        //    //document.getElementById("detail_yuding"+index).style.display="block";
        //    document.getElementById("up_arrow_yuding"+index).style.display = "none";
        //    document.getElementById("down_arrow_yuding"+index).style.display = "block";
        //};
        //$scope.collapse_yuding = function(index){
        //    $("#detail_yuding"+index).slideToggle();
        //    //document.getElementById("detail_yuding"+index).style.display="none";
        //    document.getElementById("up_arrow_yuding"+index).style.display = "block";
        //    document.getElementById("down_arrow_yuding"+index).style.display = "none";
        //}
    })

    .controller('yuyue_modal_ctrl',function($scope,$state,$ionicPopup,OrderService,$rootScope,$cordovaToast,$stateParams){
        //$scope.yanghuiting_list1 = $rootScope.yanghuiting_list1;

        $scope.dec_num = function(){
            var xuhao = document.getElementById("xuhao").value;
            var oldValue = parseFloat(xuhao);
            var newValue;

            if(oldValue > 0){
                newValue = oldValue - 1;
            }else{
                newValue = 0;
            }
            document.getElementById("xuhao").value = number_format(newValue);
            if(newValue == $scope.item.kanchang_xuhao){
                $("#yuyue_kc_dec").attr('disabled',true);
            }
        };
        $scope.inc_num = function(){
            $("#yuyue_kc_dec").attr('disabled',false);
            var xuhao = document.getElementById("xuhao").value;
            var oldValue = parseFloat(xuhao);
            var newValue;
            newValue = oldValue + 1;
            document.getElementById("xuhao").value = number_format(newValue);
        };
        $scope.sub =function(roomid){
            var oldValue = parseFloat($("#yyzhuoshu"+roomid).val());
            $("#add_yym"+roomid).attr('disabled',false);
            if(oldValue > 1){
                $("#yyzhuoshu"+roomid).val(oldValue-1);
            }else{
                $("#yyzhuoshu"+roomid).val(1);
            }
            if($("#yyzhuoshu"+roomid).val() == 1){
                $("#sub_yym"+roomid).attr('disabled',true);
            }
            calc_total_yymodal();
        }
        $scope.add =function(roomid){
            var oldValue = parseFloat($("#yyzhuoshu"+roomid).val());
            $("#sub_yym"+roomid).attr('disabled',false);
            $("#yyzhuoshu"+roomid).val(oldValue+1);
            //if($("#yyzhuoshu"+roomid).val() == $scope.yanghuiting_list1[roomid].zuoshu){
            //    $("#add_yym"+roomid).attr('disabled',true);
            //}
            calc_total_yymodal();
        };

        var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {

                } else {
                    var dangqi = val.format('yyyy.MM.dd');
                    document.getElementById("yuyue_dangqi").value = dangqi;
                    var type = $scope.item.yuyue_type;
                    OrderService.get_xuhao(dangqi,type).then(function(results){
                        $("#yuyue_xuhao").html(results.item.xuhao);
                        $("#xuhao").val(results.item.kanchang_xuhao);
                    });
                }
            }
        };
        $scope.datepickerObject2 = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {

                } else {
                    document.getElementById("kc_date").value = val.format('yyyy.MM.dd');
                }
            }
        };
        var kanchang_time2;
        var kanchang_time3;
        $scope.slots = {epochTime: 32400, format: 12, step: 1};
        $scope.timePickerCallback = function (val) {
            if (typeof (val) === 'undefined') {
                console.log('Time not selected');
            } else {
                var myDate= new Date(val * 1000 - 8 * 3600 * 1000);
                var hour = myDate.getHours();
                var minute = myDate.getMinutes();
                var meridian = "am";
                if(hour == 0){
                    hour = 12;
                }else if(hour <= 9){
                    hour = "0"+hour;
                }else if(hour < 12){
                    hour = hour;
                }else if(hour ==12){
                    hour = hour;
                    meridian = "pm";
                }else{
                    hour -= 12;
                    meridian = "pm";
                }
                if(minute <= 9){
                    minute = "0" +　minute;
                }
                document.getElementById("kc_time").value = hour+":"+ minute +" "+ meridian;
                kanchang_time2 = hour+":"+ minute;
                kanchang_time3 = meridian;
            }
        };
        //点击展开
        $scope.expand_yuyue_detail = function(){
            $state.go('yuyue_expand_detail',{yanghuiting_list:$scope.yanghuiting_list1,item:$scope.item});
            $scope.yuyue_modal.remove();
            $scope.on_select_yuyue($scope.dangqi);
        };
        //餐标修改 总预算变化
        $scope.change_cb = function(){
            calc_total_yymodal();
        };
        function calc_total_yymodal(){
            var total = 0;
            for(var key in $scope.yanghuiting_list1) {
                var item = $scope.yanghuiting_list1[key];
                var canbiao = $("#hunyan"+item.id).val();
                var zhuoshu = $("#yyzhuoshu"+item.id).val();
                total += canbiao * zhuoshu;
            }
            $scope.total_price = total.toFixed(2);
        };

        $scope.confirm_kanchang = function(){
            //校验
            if($("#nickname").val() == ""){
                $cordovaToast.showShortTop("预约用户不能为空！");
                return;
            }
            if($("#kc_date").val() == "" || $("#kc_time").val() == ""){
                $cordovaToast.showShortTop("看场日期不能为空！");
                return;
            }
            var dDate = new Date($("#yuyue_dangqi").val().replace(/\./g, "\/"));
            var kDate = new Date($("#kc_date").val().replace(/\./g, "\/"));
            var ctime = $scope.item.create_time;//预约时间戳
            var tmp_date = $("#kc_date").val() +" "+ $("#kc_time").val();
            var kc_time = new Date(tmp_date.replace(/\./g, "\/")).getTime().toString()/1000;//看场时间戳
            if(kDate > dDate  ){
                $cordovaToast.showShortTop("看场日期不能晚于预约档期！");
                return;
            }
            if(kc_time < ctime){
                $cordovaToast.showShortTop("看场时间不能早于预约时间！");
                return;
            }
            var arr = $scope.yanghuiting_list1;
            var length = $scope.yanghuiting_count1;
            $rootScope.tmp_list = $rootScope.yanghuiting_list_yuyue_modal;
            hunyan = [];
            zhushu = [];
            for(var key in $scope.yanghuiting_list1){
                var item = arr[key];
                zhushu[item.id] = $("#yyzhuoshu"+item.id).val();
                hunyan[item.id] = $("#hunyan"+item.id).val();
                $rootScope.tmp_list[item.id].zhushu = $("#yyzhuoshu"+item.id).val();
                $rootScope.tmp_list[item.id].price = $("#hunyan"+item.id).val();
            }
            $ionicPopup.confirm({
                title:"看场排期",
                template:"<div align='center'>"+$("#xuhao").val()+"&nbsp;看场日期&nbsp;"+$("#kc_date").val()+"&nbsp;"+$("#kc_time").val()+"<br>"
                +$("#nickname").val()+"<br>"+$("#yuyue_dangqi").val()+"&nbsp;婚宴预定<br>"+window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in tmp_list'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br></div>",
                okText: '确认',
                cancelText:'取消',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    OrderService.confirm_kanchang($scope.item.id,$("#nickname").val(),$("#yuyue_dangqi").val(),zhushu,hunyan,$("#xuhao").val(),
                        $("#kc_date").val(),kanchang_time2,kanchang_time3).then(function(results){
                            $ionicPopup.alert({
                                title:'提示',
                                template:'<div align="center">'+results.info+'</div>'
                            });
                    });
                }else{
                }
                $scope.yuyue_modal.remove();
                $scope.on_select_yuyue($scope.dangqi);
                $rootScope.doRefresh_yuyue($scope.dangqi);
            });
        }

        $scope.cancel_yuyue = function(){
            var ctime = new Date($scope.item.create_time *1000).format('yyyy.MM.dd');
            $ionicPopup.confirm({
                title:"取消预约",
                template:"<div align='center'>"+$("#xuhao").val()+"&nbsp;预约日期&nbsp;"+ctime+"<br>"
                +$scope.item.nickname+"<br>"+$("#yuyue_dangqi").val()+"&nbsp;婚宴预定<br>"+window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in yanghuiting_list_yuyue_modal'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center' style='margin-top: -20px;'>原因&nbsp;<input type='text' style='width: 170px' id='cancelReason'></div><br>是否确定取消预约？</div>",
                okText: '是',
                cancelText:'否',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    OrderService.cancel_yuyue($scope.item.id,document.getElementById("cancelReason").value).then(function(results){
                        $ionicPopup.alert({
                            title:'提示',
                            template:'<div align="center">'+results.info+'</div>'
                        });
                    });
                }else{
                }
                $scope.yuyue_modal.remove();
                $scope.on_select_yuyue($scope.dangqi);
                $rootScope.doRefresh_yuyue($scope.dangqi);
            });
        };
    })

    .controller('yuyue_expand_detail_ctrl',function($scope,$stateParams,OrderService,$ionicPopup,$cordovaToast,$state,$rootScope,$ionicHistory){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.yanghuiting_list = $stateParams.yanghuiting_list;
        $scope.item = $stateParams.item;

        $("#yuyue_kc_detail_dec").attr('disabled',true);
        $scope.dec_num = function(){
            var xuhao = document.getElementById("xuhao_detail").value;
            var oldValue = parseFloat(xuhao);
            var newValue;
            if(oldValue > 0){
                newValue = oldValue - 1;
            }else{
                newValue = 0;
            }
            document.getElementById("xuhao_detail").value = number_format(newValue);
            if(newValue == $scope.item.kanchang_xuhao){
                $("#yuyue_kc_detail_dec").attr('disabled',true);
            }
        };
        $scope.inc_num = function(){
            $("#yuyue_kc_detail_dec").attr('disabled',false);
            var xuhao = document.getElementById("xuhao_detail").value;
            var oldValue = parseFloat(xuhao);
            var newValue;
            newValue = oldValue + 1;
            document.getElementById("xuhao_detail").value = number_format(newValue);
        };
        $scope.sub =function(roomid){
            var oldValue = parseFloat($("#yyzhuoshu_detail"+roomid).val());
            $("#add_yym_exp"+roomid).attr('disabled',false);
            if(oldValue > 1){
                $("#yyzhuoshu_detail"+roomid).val(oldValue-1);
            }else{
                $("#yyzhuoshu_detail"+roomid).val(1);
            }
            if($("#yyzhuoshu_detail"+roomid).val() == 1){
                $("#sub_yym_exp"+roomid).attr('disabled',true);
            }
            calc_total_yymodal_exp();
        }
        $scope.add =function(roomid){
            var oldValue = parseFloat($("#yyzhuoshu_detail"+roomid).val());
            $("#sub_yym_exp"+roomid).attr('disabled',false);
            $("#yyzhuoshu_detail"+roomid).val(oldValue+1);
            //if($("#yyzhuoshu_detail"+roomid).val() == $scope.yanghuiting_list[roomid].zuoshu){
            //    $("#add_yym_exp"+roomid).attr('disabled',true);
            //}
            calc_total_yymodal_exp();
        };

        $('#dangqi_detail').focus(function() {
            this.blur();
        });
        $('#kc_date_detail').focus(function() {
            this.blur();
        });
        $('#kc_time_detail').focus(function() {
            this.blur();
        });
        var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    var dangqi = val.format('yyyy.MM.dd');
                    document.getElementById("dangqi_detail").value = dangqi;
                    var type = $scope.item.yuyue_type;
                    OrderService.get_xuhao(dangqi,type).then(function(results){
                        $("#yuyue_xuhao_detail").html(results.item.xuhao);
                        $("#xuhao_detail").val(results.item.kanchang_xuhao);
                    });
                }
            }
        };
        $scope.datepickerObject2 = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    document.getElementById("kc_date_detail").value = val.format('yyyy.MM.dd');
                }
            }
        };
        var kanchang_time2;
        var kanchang_time3;
        $scope.slots = {epochTime: 32400, format: 12, step: 1};
        $scope.timePickerCallback = function (val) {
            if (typeof (val) === 'undefined') {
                console.log('Time not selected');
            } else {
                var myDate= new Date(val * 1000 - 8 * 3600 * 1000);
                var hour = myDate.getHours();
                var minute = myDate.getMinutes();
                var meridian = "am";
                if(hour == 0){
                    hour = 12;
                }else if(hour <= 9){
                    hour = "0"+hour;
                }else if(hour < 12){
                    hour = hour;
                }else if(hour ==12){
                    hour = hour;
                    meridian = "pm";
                }else{
                    hour -= 12;
                    meridian = "pm";
                }
                if(minute <= 9){
                    minute = "0" +　minute;
                }
                document.getElementById("kc_time_detail").value = hour+":"+ minute +" "+ meridian;
                kanchang_time2 = hour+":"+ minute;
                kanchang_time3 = meridian;
            }
        };
        //餐标修改 总预算变化
        $scope.total_price = $scope.item.total_price;
        $scope.change_cb = function(){
            calc_total_yymodal_exp();
        };
        function calc_total_yymodal_exp(){
            var total = 0;
            for(var key in $scope.yanghuiting_list) {
                var item = $scope.yanghuiting_list[key];
                var canbiao = $("#hunyan_detail"+item.id).val();
                var zhuoshu = $("#yyzhuoshu_detail"+item.id).val();
                total += canbiao * zhuoshu;
            }
            $scope.total_price = total.toFixed(2);
        };

        $scope.confirm_kanchang = function(){
            //校验
            if($("#nickname_detail").val() == ""){
                $cordovaToast.showShortTop("联系人不能为空！");
                return;
            }
            if($("#kc_date_detail").val() == "" || $("#kc_time_detail").val() == ""){
                $cordovaToast.showShortTop("看场日期不能为空！");
                return;
            }
            var dDate = new Date($("#dangqi_detail").val().replace(/\./g, "\/"));
            var kDate = new Date($("#kc_date_detail").val().replace(/\./g, "\/"));
            var ctime = $scope.item.create_time;//预约时间戳
            var tmp_date = $("#kc_date").val() +" "+ $("#kc_time").val();
            var kc_time = new Date(tmp_date.replace(/\./g, "\/")).getTime().toString()/1000;//看场时间戳
            if(kDate > dDate  ){
                $cordovaToast.showShortTop("看场日期不能晚于预约档期！");
                return;
            }
            if(kc_time < ctime){
                $cordovaToast.showShortTop("看场时间不能早于预约时间！");
                return;
            }
            var arr = $scope.yanghuiting_list;
            $rootScope.tmp_list = $rootScope.yanghuiting_list_yuyue_modal;
            hunyan = [];
            zhushu = [];
            for(var key in arr){
                var item = arr[key];
                zhushu[item.id] = $("#yyzhuoshu_detail"+item.id).val();
                hunyan[item.id] = $("#hunyan_detail"+item.id).val();
                $rootScope.tmp_list[item.id].zhushu = $("#yyzhuoshu_detail"+item.id).val();
                $rootScope.tmp_list[item.id].price = $("#hunyan_detail"+item.id).val();
            }
            $ionicPopup.confirm({
                title:"看场排期",
                template:"<div align='center'>"+$("#xuhao_detail").val()+"&nbsp;看场日期&nbsp;"+$("#kc_date_detail").val()+"&nbsp;"+$("#kc_time_detail").val()+"<br>"
                +$("#nickname_detail").val()+"<br>"+$("#dangqi_detail").val()+"婚宴预定<br>"+window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in tmp_list'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br></div>",
                okText: '确认',
                cancelText:'取消',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    OrderService.confirm_kanchang($scope.item.id,$("#nickname_detail").val(),$("#dangqi_detail").val(),zhushu,hunyan,$("#xuhao_detail").val(),
                        $("#kc_date_detail").val(),kanchang_time2,kanchang_time3).then(function(results){
                            $ionicPopup.alert({
                                title:'提示',
                                template:'<div align="center">'+results.info+'</div>'
                            }).then(function(){
                                OrderService.query_yuyue($scope.item.dangqi).then(function(results){
                                    $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:1}, {reload: true});
                                });
                            });
                        });
                }else{
                }
            });
        }

        $scope.cancel_yuyue = function(){
            var ctime = new Date($scope.item.create_time *1000).format('yyyy.MM.dd');
            $ionicPopup.confirm({
                title:"取消预约",
                template:"<div align='center'>"+$("#xuhao_detail").val()+"&nbsp;预约日期&nbsp;"+ctime+"<br>"
                +$scope.item.nickname+"<br>"+$scope.item.dangqi+"婚宴预定<br>"+window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in yanghuiting_list_yuyue_modal'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center' style='margin-top: -20px;'>原因&nbsp;<input type='text' style='width: 170px' id='cancelReason'></div>" +
                "<br>是否确定取消预约？</div>",
                okText: '是',
                cancelText:'否',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    OrderService.cancel_yuyue($scope.item.id,document.getElementById("cancelReason").value).then(function(results){
                        $ionicPopup.alert({
                            title:'提示',
                            template:'<div align="center">'+results.info+'</div>'
                        }).then(function(){
                            OrderService.query_yuyue($scope.item.dangqi).then(function(results){
                                $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:1}, {reload: true});
                            });
                        });;
                    });
                }else{
                }
            });
        };
    })

    .controller('kanchang_modal_ctrl',function($scope,$state,$ionicPopup,OrderService,$cordovaToast,$rootScope){

        $scope.sub =function(roomid){
            var oldValue = parseFloat($("#kc_zhuoshu"+roomid).val());
            $("#add_kcm"+roomid).attr('disabled',false);
            if(oldValue > 1){
                $("#kc_zhuoshu"+roomid).val(oldValue-1);
            }else{
                $("#kc_zhuoshu"+roomid).val(1);
            }
            if($("#kc_zhuoshu"+roomid).val() == 1){
                $("#sub_kcm"+roomid).attr('disabled',true);
            }
            calc_total_kcmodal();
        }
        $scope.add =function(roomid){
            var oldValue = parseFloat($("#kc_zhuoshu"+roomid).val());
            $("#sub_kcm"+roomid).attr('disabled',false);
            $("#kc_zhuoshu"+roomid).val(oldValue+1);
            //if($("#kc_zhuoshu"+roomid).val() == $scope.yanghuiting_list1[roomid].zuoshu){
            //    $("#add_kcm"+roomid).attr('disabled',true);
            //}
            calc_total_kcmodal();
        }

        var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    var dangqi = val.format('yyyy.MM.dd');
                    document.getElementById("kc_dangqi").value = dangqi;
                    var type = $scope.item.yuyue_type;
                    OrderService.get_xuhao(dangqi,type).then(function(results){
                        $("#yuyue_xuhao_kc").html(results.item.xuhao);
                        $("#kanchang_xuhao_kc").html(results.item.kanchang_xuhao);
                    });
                }
            }
        };

        $scope.chaidan = function(){
            $state.go('kanchang_chaidan',{id:$scope.item.id});
            $scope.kanchang_modal.remove();
            $scope.on_select_kanchang($scope.dangqi);
        };
        //点击展开
        $scope.expand_kanchang_detail = function(){
            $state.go('kanchang_expand_detail',{yanghuiting_list:$scope.yanghuiting_list1,item:$scope.item});
            $scope.kanchang_modal.remove();
            $scope.on_select_kanchang($scope.dangqi);
        };

        //餐标修改 总预算变化
        $scope.change_cb = function(){
            calc_total_kcmodal();
        };
        function calc_total_kcmodal(){
            var total = 0;
            for(var key in $scope.yanghuiting_list1) {
                var item = $scope.yanghuiting_list1[key];
                var canbiao = $("#kc_hunyan"+item.id).val();
                var zhuoshu = $("#kc_zhuoshu"+item.id).val();
                total += canbiao * zhuoshu;
            }
            $scope.total_price = total.toFixed(2);
        };

        $scope.confirm_yuding = function(){
            //校验
            if($("#kc_nickname").val() == ""){
                $cordovaToast.showShortTop("预约用户不能为空！");
                return;
            }
            var arr = $scope.yanghuiting_list1;
            $rootScope.popup_kc_list = $scope.yanghuiting_list1;
            hunyan = [];
            zhushu = [];
            for(var key in arr){
                var item = arr[key];
                zhushu[item.id] = $("#kc_zhuoshu"+item.id).val();
                hunyan[item.id] = $("#kc_hunyan"+item.id).val();
                $rootScope.popup_kc_list[item.id].zhushu = $("#kc_zhuoshu"+item.id).val();
                $rootScope.popup_kc_list[item.id].price = $("#kc_hunyan"+item.id).val();
            }
            var popup = $ionicPopup.show({
                title:"确认预定",
                template:"<div align='center'>"+$scope.item.kanchang_xuhao+"看场日期"+$scope.item.action_time+"<br>"
                +$scope.item.nickname+"<br>"+$("#kc_dangqi").val()+"&nbsp;婚宴预定<br>" +window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in popup_kc_list'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center'><div class='col'>预付款</div><div class='col'><input type='tel' id='dingjin'/></div></div></div>",
                scope: $scope,
                buttons: [
                    {text:'取消'},
                    {
                        text:'确认',
                        type:'button-royal',
                        onTap: function(e) {
                            if($("#dingjin").val() == ""){
                                $cordovaToast.showShortTop("请输入预付款!");
                                e.preventDefault();
                            }else if(!checkPrice($("#dingjin").val())){
                                $cordovaToast.showShortTop("预付款格式不正确!");
                                e.preventDefault();
                            }else{
                                return true;
                            }
                        }
                    }
                ]
                });
            popup.then(function(res){
                if(res){
                    OrderService.confirm_yuding($scope.item.id,$("#kc_nickname").val(),$("#kc_dangqi").val(),$("#dingjin").val(),zhushu,hunyan).then(function(results){
                            if(results.status == 1){
                                var res_item = results.item;
                                $rootScope.rooms = res_item.yanghuiting_list;
                                $ionicPopup.show({
                                    title:"<span class='font-heiti-ud'>宴会厅档期</span>",
                                    template:"<div align='center' class='font-heiti-ud'><span style='line-height: 2em;'>请选择需要关闭档期的宴会厅<br>宴会厅档期: "+res_item.dangqi+"</span><br>" +
                                    //"<ion-checkbox ng-repeat='room in rooms' ng-model='room.selected'>" +
                                    //    //"<input type='checkbox'/>" +
                                    //    "<div class='row'><div class='col'>{{room.name}}</div>" +
                                    //    "<div class='col'>已预定{{room.yuding_zhushu_total}}桌<br>还剩余{{room.sheyu_zhushu_total}}桌</div></div>" +
                                    //    //"<i class='checkbox-icon  ion-ios-checkmark assertive'></i>"+
                                    //"</ion-checkbox>" +
                                    "<label class='item item-checkbox ng-valid' ng-repeat='room in rooms' ng-model='room.selected' style='padding: 0px;'>"+
                                    "<div class='checkbox checkbox-input-hidden disable-pointer-events checkbox-circle'>" +
                                        "<input type='checkbox' ng-model='room.selected' class='ng-untouched ng-valid ng-dirty ng-valid-parse' value='on'>" +
                                        "<i class='checkbox-icon' style='width: 23px;height: 23px;left:-46%;'></i>"+
                                    "</div>" +
                                    "<div class='item-content disable-pointer-events'>" +
                                        "<div class='row row-center'>" +
                                            "<div class='col' style='flex:3em;'>{{room.name|limitLength}}:</div>" +
                                            "<div class='col' style='margin-left: -3em;'>已预定{{room.yuding_zhushu_total}}桌<br>还剩余{{room.sheyu_zhushu_total}}桌</div>" +
                                        "</div>" +
                                    "</div>" +
                                    "</label>"+
                                    "<br>" +
                                    "</div>",
                                    buttons: [
                                        {
                                            text: '取消',
                                            onTap: function(e) {
                                                $scope.close_button = false;
                                            }
                                        },
                                        {
                                            text: '关闭',
                                            type: 'button-royal',
                                            onTap: function(e) {
                                                $scope.close_button = true;
                                                var sel_count = 0;
                                                for(var key in $rootScope.rooms){
                                                    if($rootScope.rooms[key].selected){
                                                        sel_count++;
                                                    }
                                                }
                                                if(sel_count == 0){
                                                    $cordovaToast.showShortTop("请选择宴会厅！");
                                                    e.preventDefault();
                                                }
                                            }
                                        }
                                    ]
                                }).then(function(re){
                                    if($scope.close_button){//关闭档期
                                        var yht_id="";
                                        var arr = res_item.yanghuiting_list;
                                        for(var key in $rootScope.rooms){
                                            if($rootScope.rooms[key].selected){
                                                yht_id = yht_id + key + ",";
                                            }
                                        }
                                        OrderService.close_dangqi(yht_id,res_item.dangqi).then(function(data){
                                            $ionicPopup.alert({
                                                title:'提示',
                                                template:'<div align="center">'+data.info+'</div>'
                                            });
                                        })
                                    }else{
                                    }
                                })
                            }else{
                                $ionicPopup.alert({
                                    title:'提示',
                                    template:'<div align="center">'+results.info+'</div>'
                                });
                            }
                        });
                }else{
                }
                $scope.kanchang_modal.remove();
                $scope.on_select_kanchang($scope.dangqi);
                $rootScope.doRefresh_kanchang($scope.dangqi);
            });
        }

        $scope.cancel_kanchang = function() {
            OrderService.cancel_kanchang($scope.item.id).then(function (results) {
                $ionicPopup.alert({
                    title:'提示',
                    template:'<div align="center">'+results.info+'</div>'
                });
            })
            $scope.kanchang_modal.remove();
            $scope.on_select_kanchang($scope.dangqi);
            $rootScope.doRefresh_kanchang($scope.dangqi);
        }
    })

    .controller('kanchang_expand_detail_ctrl',function($scope,$stateParams,OrderService,$ionicPopup,$state,$cordovaToast,$ionicHistory,$rootScope){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.yanghuiting_list = $stateParams.yanghuiting_list;
        $scope.item = $stateParams.item;

        $scope.sub =function(roomid){
            var oldValue = parseFloat($("#kc_zhuoshu_detail"+roomid).val());
            $("#add_kcm_exp"+roomid).attr('disabled',false);
            if(oldValue > 1){
                $("#kc_zhuoshu_detail"+roomid).val(oldValue-1);
            }else{
                $("#kc_zhuoshu_detail"+roomid).val(1);
            }
            if($("#kc_zhuoshu_detail"+roomid).val() == 1){
                $("#sub_kcm_exp"+roomid).attr('disabled',true);
            }
            calc_total_kcmodal_exp();
        }
        $scope.add =function(roomid){
            var oldValue = parseFloat($("#kc_zhuoshu_detail"+roomid).val());
            $("#sub_kcm_exp"+roomid).attr('disabled',false);
            $("#kc_zhuoshu_detail"+roomid).val(oldValue+1);
            //if($("#kc_zhuoshu_detail"+roomid).val() == $scope.yanghuiting_list[roomid].zuoshu){
            //    $("#add_kcm_exp"+roomid).attr('disabled',true);
            //}
            calc_total_kcmodal_exp();
        };
        $('#kc_dangqi_detail').focus(function() {
            this.blur();
        });
        var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    var dangqi = val.format('yyyy.MM.dd');
                    document.getElementById("kc_dangqi_detail").value = dangqi;
                    var type = $scope.item.yuyue_type;
                    OrderService.get_xuhao(dangqi,type).then(function(results){
                        $("#yuyue_xuhao_kc_detail").html(results.item.xuhao);
                        $("#kanchang_xuhao_kc_detail").html(results.item.kanchang_xuhao);
                    });
                }
            }
        };
        //餐标修改 总预算变化
        $scope.total_price = $scope.item.total_price;
        $scope.change_cb = function(){
            calc_total_kcmodal_exp();
        };
        function calc_total_kcmodal_exp(){
            var total = 0;
            for(var key in $scope.yanghuiting_list) {
                var item = $scope.yanghuiting_list[key];
                var canbiao = $("#kc_hunyan_detail"+item.id).val();
                var zhuoshu = $("#kc_zhuoshu_detail"+item.id).val();
                total += canbiao * zhuoshu;
            }
            $scope.total_price = total.toFixed(2);
        };

        $scope.confirm_yuding = function(){
            //校验
            if($("#kc_nickname_detail").val() == ""){
                $cordovaToast.showShortTop("预约用户不能为空！");
                return;
            }
            var arr = $scope.yanghuiting_list;
            $rootScope.popup_kc_detail_list = $scope.yanghuiting_list;
            hunyan = [];
            zhushu = [];
            for(var key in arr){
                var item = arr[key];
                zhushu[item.id] = $("#kc_zhuoshu_detail"+item.id).val();
                hunyan[item.id] = $("#kc_hunyan_detail"+item.id).val();
                $rootScope.popup_kc_detail_list[item.id].zhushu = $("#kc_zhuoshu_detail"+item.id).val();
                $rootScope.popup_kc_detail_list[item.id].price = $("#kc_hunyan_detail"+item.id).val();
            }
            var popup = $ionicPopup.show({
                title:"确认预定",
                template:"<div align='center'>"+$scope.item.kanchang_xuhao+"看场日期"+$scope.item.action_time+"<br>"
                +$("#kc_nickname_detail").val()+"<br>"+$("#kc_dangqi_detail").val()+"&nbsp;婚宴预定<br>" +window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room1 in popup_kc_detail_list'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room1.name}}" +
                "￥{{room1.price}}/桌 × {{room1.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center'><div class='col'>预付款</div><div class='col'><input type='tel' id='dingjin'/></div></div></div>",
                scope: $scope,
                buttons: [
                    {text:'取消'},
                    {
                        text:'确认',
                        type:'button-royal',
                        onTap: function(e) {
                            if($("#dingjin").val() == ""){
                                $cordovaToast.showShortTop("请输入预付款!");
                                e.preventDefault();
                            }else if(!checkPrice($("#dingjin").val())){
                                $cordovaToast.showShortTop("预付款格式不正确!");
                                e.preventDefault();
                            }else{
                                return true;
                            }
                        }
                    }
                ]
            });
            popup.then(function(res){
                if(res){
                    OrderService.confirm_yuding($scope.item.id,$("#kc_nickname_detail").val(),$("#kc_dangqi_detail").val(),$("#dingjin").val(),zhushu,hunyan).then(function(results){
                        if(results.status == 1){
                            var res_item = results.item;
                            $rootScope.rooms_kc_detail = res_item.yanghuiting_list;
                            $ionicPopup.show({
                                title:"<span class='font-heiti-ud'>宴会厅档期</span>",
                                template:"<div align='center' class='font-heiti-ud'><span style='line-height: 2em;'>请选择需要关闭档期的宴会厅<br>宴会厅档期: "+res_item.dangqi+"</span><br>" +
                                "<label class='item item-checkbox ng-valid' ng-repeat='room in rooms_kc_detail' ng-model='room.selected' style='padding: 0px;'>"+
                                    "<div class='checkbox checkbox-input-hidden disable-pointer-events checkbox-circle'>" +
                                        "<input type='checkbox' ng-model='room.selected' class='ng-untouched ng-valid ng-dirty ng-valid-parse' value='on'>" +
                                        "<i class='checkbox-icon' style='width: 23px;height: 23px;left:-46%;'></i>"+
                                    "</div>" +
                                    "<div class='item-content disable-pointer-events'>" +
                                        "<div class='row row-center'>" +
                                            "<div class='col' style='flex:3em;'>{{room.name|limitLength}}:</div>" +
                                            "<div class='col' style='margin-left: -3em;'>已预定{{room.yuding_zhushu_total}}桌<br>还剩余{{room.sheyu_zhushu_total}}桌</div>" +
                                        "</div>" +
                                    "</div>" +
                                "</label>"+
                                "<br>" +
                                "</div>",
                                buttons: [
                                    {
                                        text: '取消',
                                        onTap: function(e) {
                                            $scope.close_button = false;
                                        }
                                    },
                                    {
                                        text: '关闭',
                                        type: 'button-royal',
                                        onTap: function(e) {
                                            $scope.close_button = true;
                                            var sel_count = 0;
                                            for(var key in $rootScope.rooms_kc_detail){
                                                if($rootScope.rooms_kc_detail[key].selected){
                                                    sel_count++;
                                                }
                                            }
                                            if(sel_count == 0){
                                                $cordovaToast.showShortTop("请选择宴会厅！");
                                                e.preventDefault();
                                            }
                                        }
                                    }
                                ]
                            }).then(function(re){
                                OrderService.query_kanchang($scope.item.dangqi).then(function(results){
                                    $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:2}, {reload: true});
                                });
                                if($scope.close_button){//关闭档期
                                    var yht_id="";
                                    var arr = res_item.yanghuiting_list;
                                    for(var key in $rootScope.rooms_kc_detail){
                                        if($rootScope.rooms_kc_detail[key].selected) {
                                            yht_id = yht_id + key + ",";
                                        }
                                    }
                                    OrderService.close_dangqi(yht_id,res_item.dangqi).then(function(data){
                                        $ionicPopup.alert({
                                            title:'提示',
                                            template:'<div align="center">'+data.info+'</div>'
                                        });
                                    })
                                }else{
                                }
                            })
                        }
                    });
                }else{
                }
            });
        };

        $scope.cancel_kanchang = function(){
            OrderService.cancel_kanchang($scope.item.id).then(function (data) {
                $ionicPopup.alert({
                    title:'提示',
                    template:'<div align="center">'+data.info+'</div>'
                }).then(function(res){
                    OrderService.query_kanchang($scope.item.dangqi).then(function(results){
                        $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:2}, {reload: true});
                    });
                });
            })
        };
    })

    .controller('kanchang_chaidan_ctrl',function($scope,$stateParams,OrderService,$cordovaToast,$ionicPopup,$state,$ionicHistory,$rootScope,$timeout,$ionicLoading){
        //$ionicHistory.clearCache();
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $ionicLoading.show({
            template: '<span style="font-family: 黑体">正在加载中，请稍后...</span>',
            duration:2000
        });
        zhushu = [];
        hunyan = [];
        hunyan_price = [];
        var sel_room_count = 0;//选中宴会厅数量
        $rootScope.chaidan_tmp_list = new Array();
        OrderService.query_chaidan_info($stateParams.id).then(function(results){
            $scope.yanghuiting_list = results.yanghuiting_list;
            $scope.item = results.item;
            $scope.rooms = chunk(results.yanghuiting_list,3);
            $scope.is_checked_room = new Array();
            for(var key in $scope.yanghuiting_list){
                if($scope.yanghuiting_list[key].is_checked){
                    $scope.is_checked_room.push($scope.yanghuiting_list[key]);
                    zhushu[key] = $scope.yanghuiting_list[key].zhushu;
                    hunyan[key] = $scope.yanghuiting_list[key].price;
                    hunyan_price[key] = $scope.yanghuiting_list[key].price;
                    sel_room_count++;
                    $rootScope.chaidan_tmp_list[key] = $scope.yanghuiting_list[key];
                }
            }
            $scope.kanchang_date = $scope.item.action_time.substring(0,10);
            $scope.kanchang_time = $scope.item.action_time.substring(11);
        });
        //view加载完成执行操作
        $scope.$on('$ionicView.afterEnter', function(){
            $timeout( function() {
                for (var key in $scope.is_checked_room) {
                    $("#room" + $scope.is_checked_room[key].id).attr("checked", true);
                }
            },1000);
        });
        //选择宴会厅
        $scope.select_room = function(index,id){
            var room = $scope.yanghuiting_list[id];
            var is_checked = document.getElementById("room"+id).checked;
            if(is_checked){//选中
                //default_id = id;
                zhushu[id] = 1;
                hunyan[id] = 0;
                hunyan_price[id] = 0;
                sel_room_count++;
                $rootScope.chaidan_tmp_list[id] = {};
                $rootScope.chaidan_tmp_list[id].name = room.name;

                $("#change").append('<div id="button'+id+'" class="row yuyue-modal-detail-ud" style="margin: -15px 0px -15px 0px;line-height: 38px;">' +
                    '<div class="col" style="margin-left: 1%;">' +
                        '<span style="float: left">￥</span>' +
                        '<input type="number" id="chaidan_hunyan'+id+'" style="width: 60px;float: left;border: 1px solid #ECE4E3;border-radius:3px;text-align: center;" onkeyup="change_cb('+id+')" value="0"/>' +
                        '<span style="float: left">/桌</span>' +
                    '</div>' +
                    '<div class="col" style="margin-left: -25px;margin-right: -15%">'+limitString(room.name)+'</div>' +
                    '<div class="col" style="width: 300px;margin-right: 5%;">' +
                        '<button class="button button-small" id="sub_chaidan'+id+'" style="float: left;" disabled="disabled" onclick="sub_chaidan('+id+')">-</button>' +
                        '<input type="text" id="chaidan_zhuoshu'+id+'" class="text-middle-ud" style="height: 31px;" disabled="disabled" value="1"/> ' +
                        '<button class="button button-small" id="add_chaidan'+id+'" style="float: left;" onclick="add_chaidan('+id+')">+</button>' +
                    '</div>' +
                    '</div>');

                $("#room_info").append('<div id="room_div'+id+'" class="row yuyue-modal-detail-ud">' +
                    '<div class="col col-66">'+limitString(room.name)+'<br>'+room.area+'㎡ ×'+room.height+'h  &nbsp;&nbsp;已预约'+room.yuyue+'人<br>可容纳'+room.zuoshu+'桌</div>'+
                    '<div class="col"><img src="'+room.pinmiantu+'" style="width: 50px;height: 50px"></div>' +
                    '</div>');
            }else{
                hunyan.splice(id,1,"");//移除相应数组元素
                zhushu.splice(id,1,"");
                hunyan_price.splice(id,1,"");
                $rootScope.chaidan_tmp_list.splice(id,1,"");
                sel_room_count--;
                calc_total();
                $("#button"+id).remove();
                $("#room_div"+id).remove();
            }
        };
        $scope.change_cb = function(roomid){
            hunyan_price[roomid] = $("#chaidan_hunyan"+roomid).val();
            //hunyan[roomid] = $("#chaidan_hunyan"+roomid).val();
            calc_total();
        };

        $scope.add = function(roomid){
            var oldValue = parseFloat($("#chaidan_zhuoshu"+roomid).val());
            $("#sub_chaidan"+roomid).attr('disabled',false);
            $("#chaidan_zhuoshu"+roomid).val(oldValue + 1);
            //if($("#zhuoshu"+index).val() == $scope.yanghuiting_list[index].zuoshu){
            //    $("#add0").attr('disabled',true);
            //}
            zhushu[roomid] = $("#chaidan_zhuoshu"+roomid).val();
            calc_total();
        }
        $scope.sub = function(roomid){
            var oldValue = parseFloat($("#chaidan_zhuoshu"+roomid).val());
            $("#add_chaidan"+roomid).attr('disabled',false);
            if(oldValue > 1){
                $("#chaidan_zhuoshu"+roomid).val(oldValue - 1);
            }else{
                $("#chaidan_zhuoshu"+roomid).val(1);
            }
            if($("#chaidan_zhuoshu"+roomid).val() == 1){
                $("#sub_chaidan"+roomid).attr('disabled',true);
            }
            zhushu[roomid] = $("#chaidan_zhuoshu"+roomid).val();
            calc_total();
        };

        $('#kc_date_chaidan').focus(function() {
            this.blur();
        });
        $('#kc_time_chaidan').focus(function() {
            this.blur();
        });
        //日期选择
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {

                } else {
                    document.getElementById("kc_date_chaidan").value = val.format('yyyy.MM.dd');
                }
            }
        };
        var kanchang_time2;
        var kanchang_time3;
        //时间选择
        $scope.slots = {epochTime: 32400, format: 12, step: 1};
        $scope.timePickerCallback = function (val) {
            if (typeof (val) === 'undefined') {
                console.log('Time not selected');
            } else {
                var myDate= new Date(val * 1000 - 8 * 3600 * 1000);
                var hour = myDate.getHours();
                var minute = myDate.getMinutes();
                var meridian = "am";
                if(hour == 0){
                    hour = 12;
                }else if(hour <= 9){
                    hour = "0"+hour;
                }else if(hour < 12){
                    hour = hour;
                }else if(hour ==12){
                    hour = hour;
                    meridian = "pm";
                }else{
                    hour -= 12;
                    meridian = "pm";
                }
                if(minute <= 9){
                    minute = "0" +　minute;
                }
                kanchang_time2 = hour+":"+ minute;
                kanchang_time3 = meridian;
                document.getElementById("kc_time_chaidan").value = hour+":"+ minute +" "+ meridian;
            }
        };

        $scope.confirm_yuding = function(){
            //校验
            if(sel_room_count == 0){
                $cordovaToast.showShortTop('您还未选择宴会厅！');
                return;
            }
            if($("#chaidan_nickname").val()==""){
                $cordovaToast.showShortTop('联系人不能为空！');
                return;
            }
            if($("#chaidan_phone").val()==""){
                $cordovaToast.showShortTop('联系电话不能为空！');
                return;
            }
            var isMobile=/^(?:13\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/;
            var isPhone=/^((0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?$/;
            if(!isMobile.test($("#chaidan_phone").val()) && !isPhone.test($("#chaidan_phone").val())){
                $cordovaToast.showShortTop('联系电话格式不正确,请重新输入！');
                return;
            }
            if($("#kc_date_chaidan").val()==""){
                $cordovaToast.showShortTop('看场日期不能为空！');
                return;
            }
            if($("#kc_time_chaidan").val()==""){
                $cordovaToast.showShortTop('看场时间不能为空！');
                return;
            }
            var dDate = new Date($scope.item.dangqi.replace(/\./g, "\/"));
            var kDate = new Date($("#kc_date_chaidan").val().replace(/\./g, "\/"));
            if(kDate > dDate  ){
                $cordovaToast.showShortTop("看场日期不能晚于预约档期！");
                return;
            }

            for(var key in $rootScope.chaidan_tmp_list){
                zhushu[key] = $("#chaidan_zhuoshu"+key).val();
                hunyan[key] = $("#chaidan_hunyan"+key).val();
                $rootScope.chaidan_tmp_list[key].price = hunyan_price[key];
                $rootScope.chaidan_tmp_list[key].zhushu = zhushu[key];
            }
            $rootScope.chaidan_tlist = new Array();
            for(var key in  $rootScope.chaidan_tmp_list){
                if($rootScope.chaidan_tmp_list[key] != ""){
                    $rootScope.chaidan_tlist.push($rootScope.chaidan_tmp_list[key]);
                }
            }

            var popup = $ionicPopup.show({
                title:"确认预定",
                template:"<div align='center'>"+$scope.item.kanchang_xuhao+"&nbsp;看场日期&nbsp;"+$("#kc_date_chaidan").val()+"&nbsp;"+$("#kc_time_chaidan").val()+"<br>"
                +$("#chaidan_nickname").val()+"<br>"+$scope.item.dangqi+"婚宴预定<br>" +window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room in chaidan_tlist'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room.name|limitLength}}" +
                "￥{{room.price}}/桌 × {{room.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center'><div class='col'>预付款</div><div class='col'><input type='tel' id='dingjin'/></div></div></div>",
                scope: $scope,
                buttons: [
                    {text:'取消'},
                    {
                        text:'确认',
                        type:'button-royal',
                        onTap: function(e) {
                            if($("#dingjin").val() == ""){
                                $cordovaToast.showShortTop("请输入预付款!");
                                e.preventDefault();
                            }else if(!checkPrice($("#dingjin").val())){
                                $cordovaToast.showShortTop("预付款格式不正确!");
                                e.preventDefault();
                            }else{
                                return true;
                            }
                        }
                    }
                ]
            });
            popup.then(function(res){
                if(res){
                    OrderService.confirm_yuding_chaidan($scope.item.id,$("#chaidan_nickname").val(),$("#chaidan_phone").val(),$("#dingjin").val(),zhushu,hunyan,$("#kc_date_chaidan").val()
                        ,$("#kc_time_chaidan").val().substring(0,5),$("#kc_time_chaidan").val().substring(6)).then(function(results){
                        if(results.status == 1){
                            var res_item = results.item;
                            $rootScope.rooms_chaidan = res_item.yanghuiting_list;
                            $ionicPopup.show({
                                title:"<span class='font-heiti-ud'>宴会厅档期</span>",
                                template:"<div align='center' class='font-heiti-ud'><span style='line-height: 2em;'>请选择需要关闭档期的宴会厅<br>宴会厅档期: "+res_item.dangqi+"</span><br>" +
                                "<label class='item item-checkbox ng-valid' ng-repeat='room in rooms_chaidan' ng-model='room.selected' style='padding: 0px;'>"+
                                "<div class='checkbox checkbox-input-hidden disable-pointer-events checkbox-circle'>" +
                                "<input type='checkbox' ng-model='room.selected' class='ng-untouched ng-valid ng-dirty ng-valid-parse' value='on'>" +
                                "<i class='checkbox-icon' style='width: 23px;height: 23px;left:-46%;'></i>"+
                                "</div>" +
                                "<div class='item-content disable-pointer-events'>" +
                                "<div class='row row-center'>" +
                                "<div class='col' style='flex:3em;'>{{room.name|limitLength}}:</div>" +
                                "<div class='col' style='margin-left: -3em;'>已预定{{room.yuding_zhushu_total}}桌<br>还剩余{{room.sheyu_zhushu_total}}桌</div>" +
                                "</div>" +
                                "</div>" +
                                "</label>"+
                                "<br>" +
                                "</div>",
                                buttons: [
                                    {
                                        text: '取消',
                                        onTap: function(e) {
                                            $scope.close_button = false;
                                        }
                                    },
                                    {
                                        text: '关闭',
                                        type: 'button-royal',
                                        onTap: function(e) {
                                            $scope.close_button = true;
                                            var sel_count = 0;
                                            for(var key in $rootScope.rooms_chaidan){
                                                if($rootScope.rooms_chaidan[key].selected){
                                                    sel_count++;
                                                }
                                            }
                                            if(sel_count == 0){
                                                $cordovaToast.showShortTop("请选择宴会厅！");
                                                e.preventDefault();
                                            }
                                        }
                                    }
                                ]
                            }).then(function(re){
                                $ionicHistory.goBack();
                                $rootScope.doRefresh_kanchang($scope.item.dangqi);
                                //OrderService.query_kanchang($scope.item.dangqi).then(function(results){
                                //    $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:2}, {reload: true});
                                //});
                                if($scope.close_button){//关闭档期
                                    var yht_id="";
                                    for(var key in $rootScope.rooms_chaidan){
                                        if($rootScope.rooms_chaidan[key].selected){
                                            yht_id = yht_id + key + ",";
                                        }
                                    }
                                    OrderService.close_dangqi(yht_id,res_item.dangqi).then(function(data){
                                        $ionicPopup.alert({
                                            title:'提示',
                                            template:'<div align="center">'+data.info+'</div>'
                                        });
                                    })
                                }else{
                                }
                            })
                        }else{
                            $cordovaToast.showShortTop(results.info);
                            return;
                        }
                    });
                }else{
                }
            });
        };
        $scope.cancel_yuding = function(){
            OrderService.cancel_kanchang($scope.item.id).then(function (data) {
                $ionicPopup.alert({
                    title:'提示',
                    template:'<div align="center">'+data.info+'</div>'
                }).then(function(){
                    $ionicHistory.goBack();
                    $rootScope.doRefresh_kanchang($scope.item.dangqi);
                    //OrderService.query_kanchang($scope.item.dangqi).then(function(results){
                    //    $state.go("tabs", {yanghuiting_count:results.yanghuiting_count,yanghuiting_list:results.yanghuiting_list,dangqi:$scope.item.dangqi,index:2}, {reload: true});
                    //});
                });
            })
        };
    })

    .controller('yuyueAddCtrl',function($scope,OrderService,$ionicPopup,$stateParams,$rootScope,$cordovaToast,$ionicHistory,$timeout,$ionicLoading){
        //$ionicHistory.clearCache();
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $ionicLoading.show({
            template: '<span style="font-family: 黑体">正在加载中，请稍后...</span>',
            duration:2000
        });
        var date = $stateParams.dangqi;
        //var date = new Date().format('yyyy.MM.dd');
        var default_id;
        hunyan = [];
        zhushu = [];
        var sel_room_count = 1;//选中宴会厅数量
        $scope.no_room_checked = false;
        $rootScope.yuyue_tmp_list = new Array();

        OrderService.get_yuyue_add_info(date).then(function(results){
            $scope.yanghuiting_list = results.yanghuiting_list;
            $scope.room_one = results.yanghuiting_list[0];
            $scope.item = results.item;
            $scope.rooms = chunk(results.yanghuiting_list,3);
            $scope.hunyan = chunk($scope.room_one.hunyan_list,4);
            $scope.yuyue_xuhao = results.item.xuhao;
            $scope.kanchang_xuhao = results.item.kanchang_xuhao;
            default_id = $scope.room_one.id;
            initTotal();
            //确认弹框中list显示
            $rootScope.yuyue_tmp_list[$scope.room_one.id] = {};
            $rootScope.yuyue_tmp_list[$scope.room_one.id].name = $scope.room_one.name;
        });


        //view加载完成执行操作
        $scope.$on('$ionicView.afterEnter', function () {
            $timeout( function() {
                document.getElementsByName("group")[0].checked = true;
                document.getElementsByName("yuyue_cb")[0].checked = true;
                $scope.select_cb(default_id, $scope.room_one.hunyan_list[0].price, $scope.room_one.hunyan_list[0].id);
                //$("#change").append('<div id="button0"><span style="float: left;">'+$scope.room_one.name+'</span>' +
                //    '<button class="button button-small" style="float: left;" onclick="sub(0,'+$scope.room_one.id+')">-</button>' +
                //    '<input type="text" id="zhuoshu0" class="text-middle-ud" value="0" /> ' +
                //    '<button class="button button-small" style="float: left;" onclick="add(0,'+$scope.room_one.id+')">+</button></div>');
            },1000);
        });


        function initTotal(){
            zhushu[default_id] = 1;
            hunyan[default_id] = $scope.room_one.hunyan_list[0].id;
            hunyan_price[default_id] = $scope.room_one.hunyan_list[0].price;
            calc_total();
        }

        //选择宴会厅
        $scope.select_room = function(index,id){
            var room;
            for(var key in $scope.yanghuiting_list){
                if($scope.yanghuiting_list[key].id == id){
                    room = $scope.yanghuiting_list[key];
                    break;
                }
            }
            var is_checked = document.getElementById("room"+id).checked;
            if(is_checked){//选中
                document.getElementById("yuyue_cy").style.display = "block";
                $scope.hunyan = chunk(room.hunyan_list,4);
                default_id = id;
                zhushu[id] = 1;
                sel_room_count++;
                $rootScope.yuyue_tmp_list[id] = {};
                $rootScope.yuyue_tmp_list[id].name = room.name;

                $("#change").append('<div id="button'+id+'" class="row yuyue-modal-detail-ud" style="line-height: 35px;">' +
                    '<div class="col" style="margin-left: 1%;"><span id="price'+id+'"></span></div>' +
                    '<div class="col" style="margin-left: -35px;margin-right: -15%"><span style="float: left;">'+limitString(room.name)+'</span></div>' +
                    '<div class="col" style="width: 300px;margin-right: 5%;"><button class="button button-small" id="sub'+id+'" style="float: left;" disabled="disabled" onclick="sub('+id+')">-</button>' +
                    '<input type="text" id="zhuoshu'+id+'" class="text-middle-ud" style="height: 31px;" disabled="disabled" value="1"/> ' +
                    '<button class="button button-small" id="add'+id+'" style="float: left;" onclick="add('+id+','+room.zuoshu+')">+</button></div></div>');

                $("#room_info").append('<div id="room_div'+id+'" class="row yuyue-modal-detail-ud">' +
                    '<div class="col col-66">'+limitString(room.name)+'<br>'+room.area+'㎡×'+room.height+'h  &nbsp;&nbsp;已预约'+room.yuyue_total+'人<br>可容纳'+room.zuoshu+'桌</div>'+
                    '<div class="col"><img src="'+room.pinmiantu+'" style="width: 50px;height: 50px"></div>' +
                    '</div>');

                $scope.select_cb(id,room.hunyan_list[0].price,room.hunyan_list[0].id);
            }else{
                hunyan.splice(id,1,"");//移除相应数组元素
                zhushu.splice(id,1,"");
                $rootScope.yuyue_tmp_list.splice(id,1,"");
                sel_room_count--;
                calc_total();
                document.getElementById("yuyue_cy").style.display = "none";
                $("#button"+id).remove();
                $("#room_div"+id).remove();
            }

            //一个宴会厅都未选中，预约餐宴不让选
            if(sel_room_count == 0){
                $scope.no_room_checked = true;
            } else{
                $scope.no_room_checked = false;
            }
        };
        //选择餐标
        $scope.select_cb = function(yht_id,price,id){
            hunyan[default_id] = id;
            hunyan_price[default_id] = price;
            document.getElementById("price"+yht_id).innerHTML = "￥"+price+"/桌";
            calc_total();
        };


        $scope.add = function(index){
            var oldValue = parseFloat($("#zhuoshu"+index).val());
            $("#sub0").attr('disabled',false);
            $("#zhuoshu"+index).val(oldValue + 1);
            //if($("#zhuoshu"+index).val() == $scope.yanghuiting_list[index].zuoshu){
            //    $("#add0").attr('disabled',true);
            //}
            zhushu[$scope.room_one.id] = $("#zhuoshu"+index).val();
            calc_total();
        }
        $scope.sub = function(index){
            var oldValue = parseFloat($("#zhuoshu"+index).val());
            $("#add0").attr('disabled',false);
            if(oldValue > 1){
                $("#zhuoshu"+index).val(oldValue - 1);
            }else{
                $("#zhuoshu"+index).val(1);
            }
            if($("#zhuoshu"+index).val() == 1){
                $("#sub0").attr('disabled',true);
            }
            zhushu[$scope.room_one.id] = $("#zhuoshu"+index).val();
            calc_total();
        };
        $('#dangqi').focus(function() {
            this.blur();
        });
        $('#kanchang_date').focus(function() {
            this.blur();
        });
        $('#kanchang_time').focus(function() {
            this.blur();
        });
        //日期选择
        var monthList = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {

                } else {
                    var dangqi = val.format('yyyy.MM.dd');
                    document.getElementById("dangqi").value = dangqi;
                    var type = 1;//线下
                    OrderService.get_xuhao(dangqi,type).then(function(results){
                        $scope.yuyue_xuhao = results.item.xuhao;
                        $scope.kanchang_xuhao = results.item.kanchang_xuhao;
                    });
                }
            }
        };
        $scope.datepickerObject2 = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {

                } else {
                    document.getElementById("kanchang_date").value = val.format('yyyy.MM.dd');
                }
            }
        };
        var kanchang_time2;
        var kanchang_time3;
        //时间选择
        $scope.slots = {epochTime: 32400, format: 12, step: 1};
        $scope.timePickerCallback = function (val) {
            if (typeof (val) === 'undefined') {
                console.log('Time not selected');
            } else {
                var myDate= new Date(val * 1000 - 8 * 3600 * 1000);
                var hour = myDate.getHours();
                var minute = myDate.getMinutes();
                var meridian = "am";
                if(hour == 0){
                    hour = 12;
                }else if(hour <= 9){
                    hour = "0"+hour;
                }else if(hour < 12){
                    hour = hour;
                }else if(hour ==12){
                    hour = hour;
                    meridian = "pm";
                }else{
                    hour -= 12;
                    meridian = "pm";
                }
                if(minute <= 9){
                    minute = "0" +　minute;
                }
                kanchang_time2 = hour+":"+ minute;
                kanchang_time3 = meridian;
                document.getElementById("kanchang_time").value = hour+":"+ minute +" "+ meridian;
            }
        };
        $scope.confirm_yuyue = function(){
            //OrderService
            if(sel_room_count == 0){
                $cordovaToast.showShortTop('您还未选择宴会厅！');
                return;
            }
            if($("#nickname").val()==""){
                $cordovaToast.showShortTop('联系人不能为空！');
                return;
            }
            if($("#phone").val()==""){
                $cordovaToast.showShortTop('联系电话不能为空！');
                return;
            }
            var isMobile=/^(?:13\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/;
            var isPhone=/^((0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?$/;
            if(!isMobile.test($("#phone").val()) && !isPhone.test($("#phone").val())){
                $cordovaToast.showShortTop('联系电话格式不正确,请重新输入！');
                return;
            }
            if($("#kanchang_date").val()==""){
                $cordovaToast.showShortTop('看场日期不能为空！');
                return;
            }
            if($("#kanchang_time").val()==""){
                $cordovaToast.showShortTop('看场时间不能为空！');
                return;
            }
            var dDate = new Date($("#dangqi").val().replace(/\./g, "\/"));
            var kDate = new Date($("#kanchang_date").val().replace(/\./g, "\/"));
            if(kDate > dDate  ){
                $cordovaToast.showShortTop("看场日期不能晚于预约档期！");
                return;
            }

            for(var key in $rootScope.yuyue_tmp_list){
                $rootScope.yuyue_tmp_list[key].price = hunyan_price[key];
                $rootScope.yuyue_tmp_list[key].zhushu = zhushu[key];
            }
            $rootScope.tlist = new Array();
            for(var key in  $rootScope.yuyue_tmp_list){
                if($rootScope.yuyue_tmp_list[key] != ""){
                    $rootScope.tlist.push($rootScope.yuyue_tmp_list[key]);
                }
            }

            var popup = $ionicPopup.show({
                title:"预约完成",
                template:"<div align='center'>"+$scope.item.kanchang_xuhao+"看场日期"+$("#kanchang_date").val()+"&nbsp;"+kanchang_time2+kanchang_time3
                +"<br>"+$("#nickname").val()+"<br>"+$("#dangqi").val()+"&nbsp;婚宴预定<br>"+window.localStorage['sj_name']+
                "<br><div class='list' ng-repeat='room in tlist'>" +
                "<div class='row' style='height: 2px;'>" +
                "<div class='col'>{{room.name|limitLength}}" +
                "￥{{room.price}}/桌 × {{room.zhushu}}</div>" +
                "</div>" +
                "</div>"+
                "<br><div class='row row-center' style='margin-top: -10px;'><div class='col'>预付款</div><div class='col'><input type='tel' id='dingjin'></div></div></div>",
                buttons: [
                    {text: '看场'},
                    {
                        text: '预定',
                        type: 'button-royal',
                        onTap: function(e) {
                            if($("#dingjin").val() == ""){
                                $cordovaToast.showShortTop("请输入预付款！");
                                e.preventDefault();
                            }else if(!checkPrice($("#dingjin").val())){
                                $cordovaToast.showShortTop("预付款格式不正确!");
                                e.preventDefault();
                            }else{
                                return true;
                            }
                        }
                    }
                ]
            });
            popup.then(function(res) {
                if (res) {
                    OrderService.confirm_yuyue($("#dangqi").val(),zhushu,hunyan,$("#nickname").val(),$("#phone").val(),$("#kanchang_date").val(),kanchang_time2,kanchang_time3,
                        1,document.getElementById("dingjin").value).then(function (results) {
                            if(results.status == 1){
                                var res_item = results.item;
                                $rootScope.rooms_add_yuyue = res_item.yanghuiting_list;
                                $ionicPopup.show({
                                    title:"<span class='font-heiti-ud'>宴会厅档期</span>",
                                    template:"<div align='center' class='font-heiti-ud'><span style='line-height: 2em;'>请选择需要关闭档期的宴会厅<br>宴会厅档期: "+res_item.dangqi+"</span><br>" +
                                    "<label class='item item-checkbox ng-valid' ng-repeat='room in rooms_add_yuyue' ng-model='room.selected' style='padding: 0px;'>"+
                                    "<div class='checkbox checkbox-input-hidden disable-pointer-events checkbox-circle'>" +
                                    "<input type='checkbox' ng-model='room.selected' class='ng-untouched ng-valid ng-dirty ng-valid-parse' value='on'>" +
                                    "<i class='checkbox-icon' style='width: 23px;height: 23px;left:-46%;'></i>"+
                                    "</div>" +
                                    "<div class='item-content disable-pointer-events'>" +
                                    "<div class='row row-center'>" +
                                    "<div class='col' style='flex:3em;'>{{room.name|limitLength}}:</div>" +
                                    "<div class='col' style='margin-left: -3em;'>已预定{{room.yuding_zhushu_total}}桌<br>还剩余{{room.sheyu_zhushu_total}}桌</div>" +
                                    "</div>" +
                                    "</div>" +
                                    "</label>"+
                                    "<br>" +
                                    "</div>",
                                    buttons: [
                                        {
                                            text: '取消',
                                            onTap: function(e) {
                                                $scope.close_button = false;
                                            }
                                        },
                                        {
                                            text: '关闭',
                                            type: 'button-royal',
                                            onTap: function(e) {
                                                $scope.close_button = true;
                                                var sel_count = 0;
                                                for(var key in $rootScope.rooms_add_yuyue){
                                                    if($rootScope.rooms_add_yuyue[key].selected){
                                                        sel_count++;
                                                    }
                                                }
                                                if(sel_count == 0){
                                                    $cordovaToast.showShortTop("请选择宴会厅！");
                                                    e.preventDefault();
                                                }
                                            }
                                        }
                                    ]
                                }).then(function(res){
                                    //跳转到预定tab
                                    OrderService.get_yuding_info($scope.item.dangqi);
                                    $timeout( function() {
                                        $rootScope.doRefresh_yuding($scope.item.dangqi);
                                    },1000);
                                    if($scope.close_button){//关闭档期  这边添加close_button标识 解决res无法识别的问题（不知道为什么）
                                        var yht_id="";
                                        for(var key in $rootScope.rooms_add_yuyue){
                                            if($rootScope.rooms_add_yuyue[key].selected){
                                                yht_id = yht_id + key + ",";
                                            }
                                        }
                                        OrderService.close_dangqi(yht_id,res_item.dangqi).then(function(data){
                                            $ionicPopup.alert({
                                                title:'提示',
                                                template:'<div align="center">'+data.info+'</div>'
                                            });
                                        })
                                    }else{
                                    }
                                })
                            }else{//返回信息失败
                                $ionicPopup.alert({
                                    title:'提示',
                                    template:'<div align="center">'+results.info+'</div>'
                                });
                            }
                    });
                } else {
                    OrderService.confirm_yuyue($("#dangqi").val(),zhushu,hunyan,$("#nickname").val(),$("#phone").val(),$("#kanchang_date").val(),kanchang_time2,kanchang_time3,
                        0,document.getElementById("dingjin").value).then(function (results) {
                            OrderService.get_kanchang_info($scope.item.dangqi);
                            $timeout( function() {
                                $rootScope.doRefresh_kanchang($scope.item.dangqi);
                            },1000);
                        });
                }
            })
        };
    })

    .controller('yudingDetailCtrl',function($scope,$stateParams,OrderService,$ionicPopup,$state,$ionicHistory,$rootScope){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        var yuding_id = $stateParams.id;
        OrderService.query_yuding_detail(yuding_id).then(function(results){
            $scope.yanghuiting_list = results.yanghuiting_list;
            $scope.item = results.item;
            if($scope.item.status == 5){
                $scope.isComplete = true;
            }else{
                $scope.isComplete = false;
            }
        });
        $scope.compelete_hunyan = function(){
            OrderService.compeleteOrCancel_yuding(yuding_id,1).then(function(results){
                if(results.status == 1){
                    $ionicPopup.alert({
                        title:'提示',
                        template:'恭喜您完成婚宴！'
                    }).then(function(){
                        $ionicHistory.goBack();
                        $rootScope.doRefresh_yuding($scope.item.dangqi);
                    });
                }else{
                    $ionicPopup.alert({
                        title:'提示',
                        template:'<div align="center">'+results.info+'</div>'
                    }).then(function(){
                        $ionicHistory.goBack();
                        $rootScope.doRefresh_yuding($scope.item.dangqi);
                    });
                }
            });
        }
        $scope.cancel_yuding = function(){
            OrderService.compeleteOrCancel_yuding(yuding_id,-1).then(function(results){
                if(results.status == 1){
                    $ionicPopup.alert({
                        title:'提示',
                        template:'取消预定完成！'
                    }).then(function(){
                        $ionicHistory.goBack();
                        $rootScope.doRefresh_yuding($scope.item.dangqi);
                    });
                }else{
                    $ionicPopup.alert({
                        title:'提示',
                        template:'<div align="center">'+results.info+'</div>'
                    }).then(function(){
                        $ionicHistory.goBack();
                        $rootScope.doRefresh_yuding($scope.item.dangqi);
                    });
                }
            });
        }
    })

    .controller('AccountCtrl', function($scope, $state,$ionicNavBarDelegate,$stateParams,UserService,$ionicHistory) {
        //$ionicNavBarDelegate.showBackButton(false);
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.title = $stateParams.sup_name;
        $scope.logo = $stateParams.logo_img;
        $scope.address = $stateParams.address;
        $scope.tel = $stateParams.tel;
        $scope.index_img_one = $stateParams.index_img[0];
        $scope.brief = $stateParams.brief;
        $scope.fuwufei = $stateParams.fuwufei;
        $scope.jingchangfei = $stateParams.jingchangfei;
        $scope.kaipingfei = $stateParams.kaipingfei;
        $scope.tingchechang = $stateParams.tingchechang;
        $scope.hunfang = $stateParams.hunfang;
        $scope.huazhaungjian = $stateParams.huazhaungjian;
        $scope.showDetail = function(){
            $state.go('hotelDetail',{title:$scope.title,address:$scope.address,index_img:$stateParams.index_img,brief:$scope.brief
                ,fuwufei:$scope.fuwufei,jingchangfei:$scope.jingchangfei,kaipingfei:$scope.kaipingfei,
                tingchechang:$scope.tingchechang,hunfang:$scope.hunfang,huazhaungjian:$scope.huazhaungjian});
        };
        $scope.goto_yht = function(){
            UserService.get_yht_info();
        };
        $scope.goto_hycb = function(){
            UserService.get_hycb_info();
        };
        $scope.goto_order_all = function(){
            UserService.get_all_order_info();
        }
    })
    .controller('hotelDetailCtrl',function($scope, $state,$ionicSlideBoxDelegate,$stateParams,$ionicHistory){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $ionicSlideBoxDelegate.update();
        //$scope.slideCount = $ionicSlideBoxDelegate.slidesCount();
        $scope.title = $stateParams.title;
        $scope.address = $stateParams.address;
        $scope.brief = $stateParams.brief;
        $scope.fuwufei = number2word($stateParams.fuwufei);
        $scope.jingchangfei = number2word($stateParams.jingchangfei);
        $scope.kaipingfei = number2word($stateParams.kaipingfei);
        $scope.tingchechang = $stateParams.tingchechang;
        $scope.hunfang = number2word($stateParams.hunfang);
        $scope.huazhaungjian = number2word($stateParams.huazhaungjian);
        $scope.images = unique($stateParams.index_img);
        $scope.slideCount = $scope.images.length;

    })
    .controller('yhtCtrl',function($scope,$state,$stateParams,$ionicHistory){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.yanhuiting_count = $stateParams.yanhuiting_count;
        $scope.items = $stateParams.items;
    })
    .controller('hycbCtrl',function($scope,$state,$stateParams,$ionicHistory){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.hunyan_count = $stateParams.hunyan_count;
        //$scope.items = $stateParams.items;
        $scope.chunkedData = chunk($stateParams.items, 2);
    })
    .controller('hythCtrl',function($scope,$state,$ionicHistory,$stateParams,UserService,$timeout,$rootScope){
        $scope.items = $stateParams.items;
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };

        UserService.get_hyth_info(0).then(function(results){
            $scope.items = results.item;
        });
        $rootScope.doRefresh_hyth = function() {
            $timeout( function() {
                UserService.get_hyth_info(0).then(function(results){
                    $scope.items = results.item;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

    })
    .controller('hythAddCtrl',function($scope,$state,$ionicPopup,UserService,$cordovaToast,$ionicHistory,$rootScope) {
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $('#start_date').focus(function() {
            this.blur();
        });
        $('#end_date').focus(function() {
            this.blur();
        });
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    document.getElementById("start_date").value = val.format('yyyy.MM.dd');
                }
            }
        };
        $scope.datepickerObject2 = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    document.getElementById("end_date").value = val.format('yyyy.MM.dd');
                }
            }
        };
        $scope.saveActivity = function(){
            //校验
            if($("#title").val() == ""){
                $cordovaToast.showShortCenter("请输入活动标题!");
                return;
            }
            if($("#start_date").val() == ""){
                $cordovaToast.showShortCenter("请选择活动开始时间!");
                return;
            }
            if($("#end_date").val() == ""){
                $cordovaToast.showShortCenter("请选择活动结束时间!");
                return;
            }
            if($("#content").val() == ""){
                $cordovaToast.showShortCenter("请输入活动内容!");
                return;
            }
            var room = document.getElementsByName("group");
            var yht_id = 0;
            for(var i=0;i<room.length;i++){
                if(room[i].checked){
                    yht_id = i;
                }
            }
            UserService.save_hyth(yht_id,$("#title").val(),$("#start_date").val(),$("#end_date").val(),$("#content").val(),null).then(function(results){
                if(results.status ==1){
                    $ionicPopup.alert({
                        title:"保存成功",
                        template:"<div align='center'>酒店特惠活动已保存</br>我们将在一个工作日内更新至前台</div>",
                        okText: '确认',
                        okType: "button-royal"
                    }).then(function(res){
                        UserService.get_hyth_info(0).then(function(results){
                            //$state.go('hythPage',{items:results.item}, {reload: true});
                            $ionicHistory.goBack();
                            $rootScope.doRefresh_hyth();
                        });
                    });
                }else{
                    $ionicPopup.alert({
                        title:'提示',
                        template:'<div align="center">'+results.info+'</div>'
                    }).then(function(res){
                        UserService.get_hyth_info(0).then(function(results){
                            //$state.go('hythPage',{items:results.item}, {reload: true});
                            $ionicHistory.goBack();
                            $rootScope.doRefresh_hyth();
                        });
                    });
                }
            });
        }
    })
    .controller('hythEditCtrl',function($scope,$state,$ionicPopup,$stateParams,UserService,$cordovaToast,$ionicHistory,$rootScope) {
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.id = $stateParams.id;
        UserService.get_hyth_info($scope.id).then(function(results){
            $scope.item = results.item;
            document.getElementsByName("group")[$scope.item.yht_id].checked = true;
        });
        $('#start_date_edit').focus(function() {
            this.blur();
        });
        $('#end_date_edit').focus(function() {
            this.blur();
        });
        $scope.datepickerObject = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    document.getElementById("start_date_edit").value = val.format('yyyy.MM.dd');
                }
            }
        };
        $scope.datepickerObject2 = {
            titleLabel: '选择日期',  //Optional
            todayLabel: '今天',  //Optional
            closeLabel: '关闭',  //Optional
            setLabel: '设置',  //Optional
            errorMsgLabel : 'Please select time.',    //Optional
            setButtonType : 'button-assertive',  //Optional
            inputDate: new Date(),    //Optional
            mondayFirst: true,    //Optional
            //disabledDates:disabledDates,  //Optional
            monthList:monthList,  //Optional
            //from: new Date(2015, 8, 15),   //Optional
            //to: new Date(2015, 8, 20),    //Optional
            callback: function (val) {    //Mandatory
                if (typeof(val) === 'undefined') {
                } else {
                    document.getElementById("end_date_edit").value = val.format('yyyy.MM.dd');
                }
            }
        };
        $scope.saveActivity = function(){
            //校验
            if($("#title_edit").val() == ""){
                $cordovaToast.showShortCenter("请输入活动标题!");
                return;
            }
            if($("#start_date_edit").val() == ""){
                $cordovaToast.showShortCenter("请选择活动开始时间!");
                return;
            }
            if($("#end_date_edit").val() == ""){
                $cordovaToast.showShortCenter("请选择活动结束时间!");
                return;
            }
            if($("#content_edit").val() == ""){
                $cordovaToast.showShortCenter("请输入活动内容!");
                return;
            }
            var room = document.getElementsByName("group");
            var yht_id = $scope.item.yht_id;
            for(var i=0;i<room.length;i++){
                if(room[i].checked){
                    yht_id = i;
                }
            }
            UserService.save_hyth(yht_id,$("#title_edit").val(),$("#start_date_edit").val(),$("#end_date_edit").val(),$("#content_edit").val(),$scope.id).then(function(results){
                if(results.status ==1){
                    $ionicPopup.alert({
                        title:"保存成功",
                        template:"<div align='center'>酒店特惠活动已保存</br>我们将在一个工作日内更新至前台</div>",
                        okText: '确认',
                        okType: "button-royal"
                    }).then(function(res){
                        UserService.get_hyth_info(0).then(function(results){
                            //$state.go('hythPage',{items:results.item}, {reload: true});
                            $ionicHistory.goBack();
                            $rootScope.doRefresh_hyth();
                        });
                    });
                }else{
                    $ionicPopup.alert({
                        title:'提示',
                        template:'<div align="center">'+results.info+'</div>'
                    }).then(function(res){
                        UserService.get_hyth_info(0).then(function(results){
                            //$state.go('hythPage',{items:results.item}, {reload: true});
                            $ionicHistory.goBack();
                            $rootScope.doRefresh_hyth();
                        });
                    });
                }
            })
        }
    })
    .controller('allOrderCtrl', function($scope,$stateParams,UserService,$timeout,$ionicHistory) {
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        $scope.yanghuiting_count = $stateParams.yanghuiting_count;
        $scope.yanghuiting_list = $stateParams.yanghuiting_list;
        $scope.doRefresh_all_yuding = function() {
            $timeout( function() {
                UserService.get_all_order_for_refresh().then(function(results){
                    $scope.yanghuiting_list = results.yanghuiting_list;
                });
                //Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };

        $scope.slide_allOrder = function(index){
            $("#orderDetail"+index).slideToggle();
            var up_arroe_state =$("#up_arrow"+index).css('display');
            if(up_arroe_state == "none"){
                $("#up_arrow"+index).css('display','block');
                $("#down_arrow"+index).css('display','none');
            }else{
                $("#up_arrow"+index).css('display','none');
                $("#down_arrow"+index).css('display','block');
            }
        };
        //$scope.expand_order = function(index){
        //    $("#orderDetail"+index).slideToggle();
        //    //document.getElementById("orderDetail"+index).style.display="block";
        //    document.getElementById("up_arrow"+index).style.display = "none";
        //    document.getElementById("down_arrow"+index).style.display = "block";
        //};
        //$scope.collapse_order = function(index){
        //    $("#orderDetail"+index).slideToggle();
        //    //document.getElementById("orderDetail"+index).style.display="none";
        //    document.getElementById("up_arrow"+index).style.display = "block";
        //    document.getElementById("down_arrow"+index).style.display = "none";
        //}
    })
    .controller('scheduleCtrl',function($scope,$ionicPopup,UserService,OrderService,$rootScope,$ionicHistory,$timeout){
        $scope.backGo = function(){
            $ionicHistory.goBack();
        };
        var selected_date_array = new Array();
        //var is_first_load = true;
        $(function() {
            $(document).on('shown.calendar.calendario2', function(e, instance){
                selected_date_array = new Array();
                if(!instance) instance = cal;
                var $cell = instance.getCell(new Date().getDate());
                $scope.instance2 = instance;
                UserService.query_dangqi_setting(instance.getYear(),instance.getMonth(),null).then(function(results){
                    var items = results.item;
                    for(var i=1;i<=31;i++){
                        $scope.instance2.getCell(parseInt(i)).removeClass("fc-selected");
                        if(items != undefined && items[i] == i){
                            $scope.instance2.getCell(parseInt(i)).addClass("fc-close");
                        }else{
                            $scope.instance2.getCell(parseInt(i)).removeClass("fc-close");
                        }
                    }
                });
                $timeout(function(){
                    if($cell.hasClass('fc-today')) $cell.trigger('click.calendario');
                },1000);
            });

            var transEndEventNames = {
                    'WebkitTransition' : 'webkitTransitionEnd',
                    'MozTransition' : 'transitionend',
                    'OTransition' : 'oTransitionEnd',
                    'msTransition' : 'MSTransitionEnd',
                    'transition' : 'transitionend'
                },
                transEndEventName = transEndEventNames[ Modernizr.prefixed( 'transition' ) ],
                $wrapper = $( '#custom-inner2' ),
                $calendar = $( '#calendar_setting' ),

                cal = $calendar.calendario2({
                    onDayClick : function( $el, data, dateProperties ) {
                        $scope.dangqi = dateProperties.year+"."+dateProperties.month+"."+dateProperties.day;
                        $scope.pdate = parseInt(dateProperties.year + parse_date(dateProperties.month) + parse_date(dateProperties.day));
                        if($el[0].firstChild.className !="fc-date fc-emptydate") {
                            document.getElementById("selected_date").innerHTML="当前选择日期："+dateProperties.year+"."+dateProperties.month+"."+dateProperties.day;

                            var has_in = false;
                            for (var key in selected_date_array) {
                                if (selected_date_array[key] === $scope.pdate) {//取消选中
                                    selected_date_array.splice(key,1);
                                    $el[0].classList.remove("fc-selected");
                                    has_in = true;
                                    if(selected_date_array.length > 0){
                                        var last_date = selected_date_array[selected_date_array.length-1].toString();
                                        UserService.query_dangqi_setting(last_date.substring(0,4),last_date.substring(4,6),last_date.substring(6)).then(function(results){
                                            if(results.item == null){//档期未关闭
                                                $scope.closeButton = true;
                                                $scope.releaseButton = false;
                                            }else{
                                                $scope.closeButton = false;
                                                $scope.releaseButton = true;
                                            }
                                        });
                                    }
                                    break;
                                }
                            }
                            if(!has_in){//选中
                                selected_date_array.push($scope.pdate);
                                $el[0].classList.add("fc-selected");
                                UserService.query_dangqi_setting(dateProperties.year,dateProperties.month,dateProperties.day).then(function(results){
                                    if(results.item == null){//档期未关闭
                                        $scope.closeButton = true;
                                        $scope.releaseButton = false;
                                    }else{
                                        $scope.closeButton = false;
                                        $scope.releaseButton = true;
                                    }
                                });
                            }
                            //is_first_load = false;
                        }
                    },
                    //caldata : codropsEvents,
                    weekabbrs  : [ '日', '一', '二', '三', '四', '五', '六' ],
                    //monthabbrs : [ '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月' ],
                    months  : [ '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月' ],
                    displayWeekAbbr : true,
                    // left-most day in the calendar  0- Sunday, 1 - Monday, ... , 6 - Saturday
                    startIn : 0,
                    events: 'click'
                } ),
                $month = $( '#custom-month2' ).html( cal.getMonthName() ),
                $year = $( '#custom-year2' ).html( cal.getYear() );

            //cal.setData(codropsEvents);

            $( '#custom-next2' ).on( 'click', function() {
                cal.gotoNextMonth2( updateMonthYear );
            } );
            $( '#custom-prev2' ).on( 'click', function() {
                cal.gotoPreviousMonth2( updateMonthYear );
            } );
            function updateMonthYear() {
                $month.html( cal.getMonthName() );
                $year.html( cal.getYear() );
                selected_date_array = new Array();
            }
            // just an example..
            function showEvents( contentEl, dateProperties ) {
                hideEvents();
                var $events = $( '<div id="custom-content-reveal" class="custom-content-reveal"><h4>Events for ' + dateProperties.monthname + ' ' + dateProperties.day + ', ' + dateProperties.year + '</h4></div>' ),
                    $close = $( '<span class="custom-content-close"></span>' ).on( 'click', hideEvents );
                $events.append( contentEl.join('') , $close ).insertAfter( $wrapper );
                setTimeout( function() {
                    $events.css( 'top', '0%' );
                }, 25 );
            }
            function hideEvents() {
                var $events = $( '#custom-content-reveal' );
                if( $events.length > 0 ) {
                    $events.css( 'top', '100%' );
                    Modernizr.csstransitions ? $events.on( transEndEventName, function() { $( this ).remove(); } ) : $events.remove();
                }
            }
        });
        $scope.jump_to_yuyue_tab = function(){
            OrderService.get_yuyue_info($scope.dangqi);
        };

        $scope.closeSchedule = function(){
            var period = new Array();
            var array_temp = arrange(selected_date_array.sort(function(a,b){return a-b;}));
            for(var key in array_temp){
                var pe_str = array_temp[key][0]+"-"+array_temp[key][array_temp[key].length-1];
                period.push(pe_str);
            }
            $rootScope.period_close = period;
             $ionicPopup.confirm({
                title:"关闭档期",
                template:"<div align='center'>酒店档期"+
                "<div class='list' ng-repeat='item in period_close'>" +
                "<div class='row' style='margin-bottom: -40px;'><div class='col col-center'>{{item}}</div>" +
                "</div></div>"+"<br>是否确认关闭该档期酒店预约？</div>",
                okText: '是',
                cancelText:'否',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    UserService.close_dangqi(period).then(function(results){
                        $ionicPopup.alert({
                            title:'提示',
                            template:'<div align="center">'+results.info+'</div>'
                        }).then(function(){
                            $scope.instance2.$el.trigger($.Event('shown.calendar.calendario2'), [$scope.instance2]);
                        });
                    });
                    //$scope.instance2.$el.trigger($.Event('shown.calendario2'));
                }
            });
        };
        $scope.releaseSchedule = function(){
            var period = new Array();
            var array_temp = arrange(selected_date_array.sort(function(a,b){return a-b;}));
            for(var key in array_temp){
                var pe_str = array_temp[key][0]+"-"+array_temp[key][array_temp[key].length-1];
                period.push(pe_str);
            }
            $rootScope.period_release = period;
            $ionicPopup.confirm({
                title:"释放档期",
                template:"<div align='center'>酒店档期"+"<div class='list' ng-repeat='item in period_release'>" +
                "<div class='row' style='margin-bottom: -40px;'><div class='col col-center'>{{item}}</div>" +
                "</div></div>"+"<br>是否确认释放该档期酒店预约？</div>",
                okText: '是',
                cancelText:'否',
                okType: "button-royal"
            }).then(function(res){
                if(res){
                    UserService.open_dangqi(period).then(function(results){
                        $ionicPopup.alert({
                            title:'提示',
                            template:'<div align="center">'+results.info+'</div>'
                        }).then(function(){
                            $scope.instance2.$el.trigger($.Event('shown.calendar.calendario2'), [$scope.instance2]);
                        });
                    });
                }
            });
        }
    })
    .controller('changePasswordCtrl',function($scope,$ionicPopup,UserService,$state,$rootScope,$ionicHistory,$cordovaToast) {
        $scope.backGo = function () {
            $ionicHistory.goBack();
        };
        $scope.completeChange = function(){
            var oldPwd = $("#oldPwd").val();
            var newPwd = $("#newPwd").val();
            var confirmPwd = $("#confirmPwd").val();
            if(oldPwd == ""){
                $cordovaToast.showShortTop("请输入原密码！");
                return;
            }
            if(oldPwd != $rootScope.user_pwd){
                $cordovaToast.showShortTop("原密码不正确，请重新输入！");
                return;
            }
            if(newPwd == ""){
                $cordovaToast.showShortTop("请输入新密码！");
                return;
            }
            if(confirmPwd == ""){
                $cordovaToast.showShortTop("请输入确认密码！");
                return;
            }
            if(newPwd != confirmPwd){
                $cordovaToast.showShortTop("新密码和确认密码不一致！");
                return;
            }
            UserService.changePassword(newPwd).then(function(res){
                if(res.status == 1){
                    $cordovaToast.showShortTop("密码修改成功，请重新登录！");
                    localStorage.removeItem("userPassword");
                    $state.go("login",{},{reload:true});
                }else{
                    $cordovaToast.showShortTop(res.info);
                    return;
                }
            });
        }
    });

/**
 * 数组去重
 * @param arr
 * @returns {Array}
 */
function unique(arr) {
    var result = [], hash = {};
    for (var i = 0, elem; (elem = arr[i]) != null; i++) {
        if (!hash[elem]) {
            result.push(elem);
            hash[elem] = true;
        }
    }
    return result;
}
/**
 * 字符转化
 * @param number
 * @returns {string}
 */
function number2word(number){
    var word='';
    if(number == 0){
        word = '无';
    }else if(number == 1){
        word = '有';
    }else{
        word = '未定义';
    }
    return word;
}
/**
 * 数组分组
 * @param arr
 * @param size
 * @returns {Array}
 */
function chunk(arr, size) {
    var newArr = [];
    var tmp_arr = [];
    for(var key in arr){
        tmp_arr.push(arr[key]);
    }
    for (var i=0; i<tmp_arr.length; i+=size) {
        newArr.push(tmp_arr.slice(i, i+size));
    }
    return newArr;
}
/**
 * 日期格式化
 * @param format
 * @returns {*}
 */
Date.prototype.format =function(format){
    var o = {
        "M+" : this.getMonth()+1, //month
        "d+" : this.getDate(),    //day
        "h+" : this.getHours(),   //hour
        "m+" : this.getMinutes(), //minute
        "s+" : this.getSeconds(), //second
        "q+" : Math.floor((this.getMonth()+3)/3),  //quarter
        "S" : this.getMilliseconds() //millisecond
    }
    if(/(y+)/.test(format)) format=format.replace(RegExp.$1,
        (this.getFullYear()+"").substr(4- RegExp.$1.length));
    for(var k in o)if(new RegExp("("+ k +")").test(format))
        format = format.replace(RegExp.$1,
            RegExp.$1.length==1? o[k] :
                ("00"+ o[k]).substr((""+ o[k]).length));
    return format;
};
/**
 * 加操作
 * @param index
 */
function add(id,zuoshu){
    var oldValue = parseFloat($("#zhuoshu"+id).val());
    $("#sub"+id).attr('disabled',false);
    $("#zhuoshu"+id).val(oldValue + 1);
    //if($("#zhuoshu"+index).val() == zuoshu){
    //    $("#add"+index).attr('disabled',true);
    //}
    zhushu[id] = $("#zhuoshu"+id).val();
    calc_total();
}
/**
 * 减操作
 * @param index
 */
function sub(id){
    var oldValue = parseFloat($("#zhuoshu"+id).val());
    $("#add"+id).attr('disabled',false);
    if(oldValue > 1){
        $("#zhuoshu"+id).val(oldValue - 1);
    }else{
        $("#zhuoshu"+id).val(1);
    }
    if($("#zhuoshu"+id).val() == 1){
        $("#sub"+id).attr('disabled',true);
    }
    zhushu[id] = $("#zhuoshu"+id).val();
    calc_total();
}
/**
 * 拆单桌数加操作
 * @param index
 */
function add_chaidan(id){
    var oldValue = parseFloat($("#chaidan_zhuoshu"+id).val());
    $("#sub_chaidan"+id).attr('disabled',false);
    $("#chaidan_zhuoshu"+id).val(oldValue + 1);
    //if($("#zhuoshu"+index).val() == zuoshu){
    //    $("#add"+index).attr('disabled',true);
    //}
    zhushu[id] = $("#chaidan_zhuoshu"+id).val();
    calc_total();
}
/**
 * 拆单桌数减操作
 * @param index
 */
function sub_chaidan(id){
    var oldValue = parseFloat($("#chaidan_zhuoshu"+id).val());
    $("#add_chaidan"+id).attr('disabled',false);
    if(oldValue > 1){
        $("#chaidan_zhuoshu"+id).val(oldValue - 1);
    }else{
        $("#chaidan_zhuoshu"+id).val(1);
    }
    if($("#chaidan_zhuoshu"+id).val() == 1){
        $("#sub_chaidan"+id).attr('disabled',true);
    }
    zhushu[id] = $("#chaidan_zhuoshu"+id).val();
    calc_total();
}
/**
 * 计算预算总价
 */
function calc_total(){
    var total = 0.00;
    for(var item in hunyan){
        total +=hunyan_price[item]*zhushu[item];
    }
    document.getElementById("total_price").innerHTML = "￥"+total.toFixed(2);
}

/**
 * 日期格式化
 * @param value
 * @returns {*}
 */
function parse_date(value){
    if(parseInt(value) < 10 ){
        value = "0" + value;
    }
    return value.toString();
}
/**
 * 相连日期分组
 * @param source
 * @returns {Array}
 */
function arrange(source) {
    var t;
    var ta;
    var r = [];
    source.forEach(function(v) {
        if (t === v) {
            ta.push(t);
            t++;
            return;
        }
        ta = [v];
        t = v + 1;
        r.push(ta);
    });
    return r;
}

function number_format(value){
    var str;
    if(value < 10){
        str = "00"+value;
    }else if(value < 100){
        str = "0"+value;
    }else{
        str = value;
    }
    return str;
}

function change_cb(roomid){
    hunyan_price[roomid] = $("#chaidan_hunyan"+roomid).val();
    calc_total();
}

function limitString(str){
    if(str.length > 4){
        return str.substring(0,4)+"...";
    }else{
        return str;
    }
}
function checkPrice(price){
    return (/^(([1-9]\d*)|\d)(\.\d{1,2})?$/).test(price.toString());
}

